#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <memory>
#include <numbers>
#include <optional>
#include <stdexcept>
#include <string>
#include <vector>
#include <variant>

#include <eigen3/Eigen/Dense>
#include <pluginlib/class_list_macros.hpp>
#include <rclcpp/logging.hpp>
#include <rclcpp/node.hpp>
#include <rmcs_executor/component.hpp>
#include <rmcs_msgs/switch.hpp>

#include "identification/wheel_leg_pair_identification_planner.hpp"
#include "identification/wheel_leg_pair_sweep_plan.hpp"
#include "identification/wheel_leg_pair_multiband_plan.hpp"

namespace rmcs_core::controller::identification {

class WheelLegPairIdentificationController final
    : public rmcs_executor::Component
    , public rclcpp::Node {
    using Clock = std::chrono::steady_clock;

public:
    WheelLegPairIdentificationController()
        : Node(
              get_component_name(),
              rclcpp::NodeOptions{}.automatically_declare_parameters_from_overrides(true)) {
        const auto side = get_parameter("side").as_string();
        if (side != "left" && side != "right")
            throw std::invalid_argument("Identification requires exactly one side: left or right");
        side_ = side == "left" ? 0 : 1;
        stage_ = parse_experiment_stage(get_parameter_or<std::string>("experiment_stage", "hold"));
        phase_api_angle_ = get_parameter_or("phase_api_angle", false);
        const auto control_law = get_parameter_or<std::string>("control_law", "cascade_pi");
        if (control_law != "cascade_pi" && control_law != "rl_pd")
            throw std::invalid_argument("control_law must be cascade_pi or rl_pd");
        rl_pd_ = control_law == "rl_pd";
        if (get_parameter("control_frequency_hz").as_double() != 1000.0)
            throw std::invalid_argument("Paired PD/PI must recompute from feedback at 1000 Hz");
        if (rl_pd_) {
            const double reference_hz = get_parameter("reference_frequency_hz").as_double();
            if (reference_hz != 50.0 && reference_hz != 200.0)
                throw std::invalid_argument("PD reference must explicitly select 50 or 200 Hz");
            reference_ticks_ = static_cast<std::size_t>(1000.0 / reference_hz);
        }
        hold_test_duration_s_ = get_parameter("hold_test_duration_s").as_double();
        if (!std::isfinite(hold_test_duration_s_) || hold_test_duration_s_ < 0.1
            || hold_test_duration_s_ > 5.0)
            throw std::invalid_argument("hold_test_duration_s must be between 0.1 and 5 seconds");

        load_array("model_sign", limits_.sign);
        load_array("model_offset", limits_.offset);
        load_array("root_min", limits_.root_min);
        load_array("root_max", limits_.root_max);
        load_array("max_speed", limits_.max_speed);
        load_array("max_acceleration", limits_.max_acceleration);
        load_array("braking_acceleration", limits_.braking_acceleration);
        load_array("max_torque", limits_.max_torque);
        if (rl_pd_ && (get_parameter("dm_motor_family").as_string() != "DM-J8009"
                       || get_parameter("dm_rated_torque_nm").as_double() != 20.0
                       || get_parameter("dm_peak_torque_nm").as_double() != 40.0
                       || std::any_of(limits_.max_torque.begin(), limits_.max_torque.end(),
                                      [](double cap) { return !std::isfinite(cap) || cap <= 0 || cap > 40; })))
            throw std::invalid_argument("RL PD requires DM-J8009 rated20/peak40 torque contract");
        if (stage_ == ExperimentStage::kTrajectory) {
            load_array("inertia_bound", limits_.inertia_bound);
            load_array("load_torque_bound", limits_.load_torque_bound);
            load_array("viscous_bound", limits_.viscous_bound);
        }
        load_array("spring_delta_min", limits_.spring_min);
        load_array("spring_delta_max", limits_.spring_max);
        limits_.joint_margin = get_parameter("joint_margin").as_double();
        limits_.spring_margin = get_parameter("spring_margin").as_double();
        limits_.beta_margin =
            get_parameter("beta_margin_degrees").as_double() * std::numbers::pi / 180.0;
        validate_limits(limits_, stage_ == ExperimentStage::kTrajectory);
        if (stage_ != ExperimentStage::kProbe) {
            luts_[0] = KneeLut{
                get_parameter("left_beta_degrees").as_double_array(),
                get_parameter("left_delta_rad").as_double_array()};
            luts_[1] = KneeLut{
                get_parameter("right_beta_degrees").as_double_array(),
                get_parameter("right_delta_rad").as_double_array()};
            // Both sides are measured and checked, although only one is driven.
            for (std::size_t side_index = 0; side_index < 2; ++side_index) {
                const auto& lut = luts_[side_index];
                const double safe_min =
                    std::max(KneeLut::kBetaMin, lut.beta_min()) + limits_.beta_margin;
                const double safe_max =
                    std::min(KneeLut::kBetaMax, lut.beta_max()) - limits_.beta_margin;
                if (!(safe_min < safe_max))
                    throw std::invalid_argument(
                        "Measured knee LUT has no safe interior after margin");
                for (const double beta : {safe_min, safe_max}) {
                    const double delta = luts_[side_index].at(beta).delta;
                    if (delta <= limits_.spring_min[side_index] + limits_.spring_margin
                        || delta >= limits_.spring_max[side_index] - limits_.spring_margin)
                        throw std::invalid_argument("Measured knee range exceeds spring travel");
                }
            }
        }

        if (!has_parameter("probe_measured_delta_policy"))
            declare_parameter<std::string>("probe_measured_delta_policy", "stop");
        const auto delta_policy = get_parameter("probe_measured_delta_policy").as_string();
        if (delta_policy != "stop" && delta_policy != "diagnostic")
            throw std::invalid_argument("probe_measured_delta_policy must be stop or diagnostic");
        probe_delta_diagnostic_ = delta_policy == "diagnostic";
        if (probe_delta_diagnostic_ && stage_ != ExperimentStage::kProbe)
            throw std::invalid_argument("Diagnostic drive difference requires experiment_stage probe");

        if (stage_ == ExperimentStage::kProbe) {
            const auto pattern = get_parameter("probe_pattern").as_string();
            if (pattern != "bounded" && pattern != "rotation_chirp" && pattern != "multiband_chirp")
                throw std::invalid_argument("probe_pattern must be bounded, rotation_chirp or multiband_chirp");
            multiband_enabled_ = pattern == "multiband_chirp";
            sweep_enabled_ = pattern != "bounded";
        }
        if (multiband_enabled_) {
            load_array("multiband_common_hz", multiband_.common_hz);
            load_array("multiband_relative_hz", multiband_.relative_hz);
            load_array("multiband_common_amplitude", multiband_.common_amplitude);
            load_array("multiband_relative_amplitude", multiband_.relative_amplitude);
            load_array("multiband_band_s", multiband_.band_s);
            multiband_.shape_offset = get_parameter("multiband_shape_offset").as_double();
            multiband_.eighth_turn_s = get_parameter("multiband_eighth_turn_s").as_double();
            multiband_.dwell_s = get_parameter("multiband_dwell_s").as_double();
            multiband_.ramp_s = get_parameter("multiband_ramp_s").as_double();
            multiband_.common_step = get_parameter("multiband_common_step").as_double();
            multiband_.relative_step = get_parameter("multiband_relative_step").as_double();
            multiband_.step_rise_s = get_parameter("multiband_step_rise_s").as_double();
            multiband_.validation_s = get_parameter("multiband_validation_s").as_double();
            if (!has_parameter("multiband_load_offset"))
                declare_parameter<double>("multiband_load_offset", 0.0);
            if (!has_parameter("multiband_validation_relative_scale"))
                declare_parameter<double>("multiband_validation_relative_scale", 1.0);
            multiband_.load_offset = get_parameter("multiband_load_offset").as_double();
            multiband_.validation_relative_scale = get_parameter("multiband_validation_relative_scale").as_double();
            PairMultibandPlan::validate_config(multiband_);
            if (!phase_api_angle_)
                throw std::invalid_argument("Multiband rotations require phase_api_angle unwrapping");
        }
        if (stage_ == ExperimentStage::kProbe && sweep_enabled_ && !multiband_enabled_) {
            sweep_.common_amplitude = get_parameter("sweep_common_amplitude").as_double();
            sweep_.relative_amplitude = get_parameter("sweep_relative_amplitude").as_double();
            sweep_.common_step = get_parameter("sweep_common_step").as_double();
            sweep_.relative_step = get_parameter("sweep_relative_step").as_double();
            sweep_.step_rise_s = get_parameter("sweep_step_rise_s").as_double();
            sweep_.move_s = get_parameter("sweep_move_s").as_double();
            sweep_.quarter_turn_s = get_parameter("sweep_quarter_turn_s").as_double();
            sweep_.dwell_s = get_parameter("sweep_dwell_s").as_double();
            sweep_.chirp_s = get_parameter("sweep_chirp_s").as_double();
            sweep_.validation_s = get_parameter("sweep_validation_s").as_double();
            sweep_.ramp_s = get_parameter("sweep_ramp_s").as_double();
            sweep_.relative_margin = get_parameter("sweep_relative_margin").as_double();
            load_array("sweep_common_hz", sweep_.common_hz);
            load_array("sweep_relative_hz", sweep_.relative_hz);
            PairSweepPlan::validate_config(sweep_);
            if (!phase_api_angle_)
                throw std::invalid_argument("Full rotations require phase_api_angle unwrapping");
        }
        if (stage_ == ExperimentStage::kProbe && !sweep_enabled_) {
            probe_.common_amplitude = get_parameter("probe_common_amplitude").as_double();
            probe_.knee_amplitude = get_parameter("probe_knee_amplitude").as_double();
            probe_.sine_common_amplitude = get_parameter("probe_sine_common_amplitude").as_double();
            probe_.sine_knee_amplitude = get_parameter("probe_sine_knee_amplitude").as_double();
            probe_.move_s = get_parameter("probe_move_s").as_double();
            probe_.hold_s = get_parameter("probe_hold_s").as_double();
            probe_.excite_s = get_parameter("probe_excite_s").as_double();
            probe_.validation_s = get_parameter("probe_validation_s").as_double();
            probe_.gravity_hold_s = get_parameter("probe_gravity_hold_s").as_double();
            probe_.step_amplitude = get_parameter("probe_step_amplitude").as_double();
            probe_.step_rise_s = get_parameter("probe_step_rise_s").as_double();
            probe_.triangle_amplitude = get_parameter("probe_triangle_amplitude").as_double();
            const auto triangle_frequency = get_parameter("probe_triangle_frequency_hz");
            probe_.triangle_frequency_hz = triangle_frequency.as_double();
            probe_.triangle_s = get_parameter("probe_triangle_s").as_double();
            probe_min_interior_delta_ = get_parameter("probe_min_interior_delta").as_double();
            if (!std::isfinite(probe_min_interior_delta_) || probe_min_interior_delta_ <= 0
                || probe_min_interior_delta_ >= probe_.knee_amplitude)
                throw std::invalid_argument("Invalid required probe knee opening progress");
            const auto frequencies = get_parameter("probe_frequencies_hz").as_double_array();
            const auto validation =
                get_parameter("probe_validation_frequencies_hz").as_double_array();
            if (frequencies.size() != 2 || validation.size() != 2)
                throw std::invalid_argument("Probe frequencies require two values per segment");
            std::copy(frequencies.begin(), frequencies.end(), probe_.frequencies_hz.begin());
            std::copy(
                validation.begin(), validation.end(), probe_.validation_frequencies_hz.begin());
            PairProbePlan::validate_config(probe_);
        }
        if (stage_ == ExperimentStage::kTrajectory) {
            trajectory_.pose_hip = get_parameter("pose_hip").as_double_array();
            trajectory_.pose_beta_degrees = get_parameter("pose_beta_degrees").as_double_array();
            trajectory_.frequencies_hz = get_parameter("frequencies_hz").as_double_array();
            trajectory_.hip_amplitudes = get_parameter("hip_amplitudes").as_double_array();
            trajectory_.beta_amplitudes_degrees =
                get_parameter("beta_amplitudes_degrees").as_double_array();
            trajectory_.move_s = get_parameter("move_s").as_double();
            trajectory_.hold_s = get_parameter("hold_s").as_double();
            trajectory_.excite_s = get_parameter("excite_s").as_double();
            trajectory_.max_hip_excitation = get_parameter("max_hip_excitation").as_double();
            trajectory_.max_beta_excitation_degrees =
                get_parameter("max_beta_excitation_degrees").as_double();
        }
        if (rl_pd_) {
            load_array("pd_kp", pd_kp_);
            load_array("pd_kd", pd_kd_);
        } else {
            load_array("kp_position", kp_position_);
            load_array("kp_velocity", kp_velocity_);
        }
        load_array("gravity_feedforward_model", gravity_feedforward_);
        load_array("integral_limit", integral_limit_);
        const auto ki = get_parameter_or<std::vector<double>>("ki_velocity", {0.0, 0.0, 0.0, 0.0});
        if (ki.size() != ki_velocity_.size())
            throw std::invalid_argument("ki_velocity requires four values");
        std::copy(ki.begin(), ki.end(), ki_velocity_.begin());
        load_array("max_position_error", max_position_error_);
        load_array("max_velocity_error", max_velocity_error_);
        load_array("max_measured_acceleration", max_measured_acceleration_);
        for (std::size_t i = 0; i < 4; ++i) {
            const double ff = gravity_feedforward_[i];
            const double max_torque = limits_.max_torque[i];
            const bool valid_feedforward = std::isfinite(ff) && std::abs(ff) <= max_torque;
            const bool valid_gains = rl_pd_
                ? (std::isfinite(pd_kp_[i]) && pd_kp_[i] > 0 && std::isfinite(pd_kd_[i])
                   && pd_kd_[i] >= 0 && ki_velocity_[i] == 0 && integral_limit_[i] == 0 && ff == 0)
                : (std::isfinite(kp_position_[i]) && kp_position_[i] > 0
                   && std::isfinite(kp_velocity_[i]) && kp_velocity_[i] > 0);
            if (!valid_gains
                || !std::isfinite(ki_velocity_[i]) || ki_velocity_[i] < 0
                || !std::isfinite(integral_limit_[i]) || integral_limit_[i] < 0
                || (ki_velocity_[i] > 0 && integral_limit_[i] <= 0)
                || !std::isfinite(max_position_error_[i]) || max_position_error_[i] <= 0
                || !std::isfinite(max_velocity_error_[i]) || max_velocity_error_[i] <= 0
                || !std::isfinite(max_measured_acceleration_[i])
                || max_measured_acceleration_[i] <= 0 || !valid_feedforward)
                throw std::invalid_argument(
                    "Invalid cascade gains, tracking, or acceleration limits");
        }
        ready_timeout_s_ = get_parameter("ready_timeout_s").as_double();
        feedback_timeout_s_ = get_parameter("feedback_timeout_s").as_double();
        max_tick_gap_s_ = get_parameter("max_tick_gap_s").as_double();
        other_side_speed_limit_ = get_parameter("other_side_speed_limit").as_double();
        const bool valid_ready = std::isfinite(ready_timeout_s_) && ready_timeout_s_ > 0;
        bool valid_feedback = std::isfinite(feedback_timeout_s_);
        valid_feedback &= feedback_timeout_s_ > 0;
        valid_feedback &= feedback_timeout_s_ <= 0.05;
        bool valid_tick = std::isfinite(max_tick_gap_s_);
        valid_tick &= max_tick_gap_s_ > 0.001;
        valid_tick &= max_tick_gap_s_ <= 0.02;
        if (!valid_ready || !valid_feedback || !valid_tick
            || !std::isfinite(other_side_speed_limit_) || other_side_speed_limit_ <= 0)
            throw std::invalid_argument(
                "Invalid identification timeouts or parked-side speed limit");

        register_input("/predefined/update_count", tick_);
        register_input("/predefined/update_rate", update_rate_);
        register_input("/predefined/timestamp", timestamp_);
        register_input("/remote/switch/left", switch_left_);
        register_input("/remote/switch/right", switch_right_);
        register_input("/wheel_leg/feedback_fresh", feedback_fresh_);
        register_input("/wheel_leg/imu/last_steady_ns", imu_feedback_ns_);
        register_input("/wheel_leg/dr16_fresh", dr16_fresh_);
        register_input("/wheel_leg/dm_control_ready", dm_control_ready_);
        for (std::size_t i = 0; i < kAxisNames.size(); ++i) {
            const auto prefix = std::string{"/wheel_leg/"} + kAxisNames[i];
            register_input(prefix + "/angle", angle_[i]);
            register_input(prefix + "/velocity", velocity_[i]);
            register_input(prefix + "/max_torque", measured_max_torque_[i]);
            register_input(prefix + "/feedback_steady_ns", feedback_ns_[i]);
            register_output(
                prefix + "/control_torque", command_torque_[i],
                std::numeric_limits<double>::quiet_NaN());
            if (i < 4) {
                register_input(prefix + "/fault_code", fault_[i]);
                register_input(prefix + "/status_code", status_[i]);
            }
        }
        register_output("/wheel_leg/enable_request", enable_request_, false);
        register_output("/wheel_leg/clear_error_request", clear_error_request_, false);
        register_output(
            "/wheel_leg/identification/reference_model", reference_model_, Eigen::Vector4d::Zero());
        register_output(
            "/wheel_leg/identification/reference_velocity_model", reference_velocity_model_,
            Eigen::Vector4d::Zero());
        register_output(
            "/wheel_leg/identification/velocity_target_model", velocity_target_model_,
            Eigen::Vector4d::Zero());
        register_output(
            "/wheel_leg/identification/position_error_model", position_error_model_,
            Eigen::Vector4d::Zero());
        register_output(
            "/wheel_leg/identification/speed_error_model", speed_error_model_,
            Eigen::Vector4d::Zero());
        register_output(
            "/wheel_leg/identification/torque_preclip_model", torque_preclip_model_,
            Eigen::Vector4d::Zero());
        register_output(
            "/wheel_leg/identification/torque_preclip_api", torque_preclip_api_,
            Eigen::Matrix<double, 6, 1>::Constant(std::numeric_limits<double>::quiet_NaN()));
        register_output(
            "/wheel_leg/identification/torque_integral_model", torque_integral_model_,
            Eigen::Vector4d::Zero());
        register_output(
            "/wheel_leg/identification/torque_gravity_ff_model", torque_gravity_ff_model_,
            Eigen::Vector4d::Zero());
        register_output("/wheel_leg/identification/phase", phase_, 0);
        register_output("/wheel_leg/identification/segment_id", segment_id_, -1);
        register_output("/wheel_leg/identification/segment_role", segment_role_, std::uint8_t{2});
        register_output(
            "/wheel_leg/identification/segment_waveform", segment_waveform_, std::uint8_t{0});
        register_output(
            "/wheel_leg/identification/repetition_id", repetition_id_output_, std::uint32_t{0});
        register_output(
            "/wheel_leg/identification/selected_side", selected_side_, static_cast<int>(side_));
        register_output("/wheel_leg/identification/failure_reason", failure_reason_, 0);
        const double nan = std::numeric_limits<double>::quiet_NaN();
        register_output(
            "/wheel_leg/identification/selected/hip/angle_model", hip_angle_model_, nan);
        register_output(
            "/wheel_leg/identification/selected/knee/angle_model", knee_angle_model_, nan);
        register_output(
            "/wheel_leg/identification/selected/hip/velocity_model", hip_velocity_model_, nan);
        register_output(
            "/wheel_leg/identification/selected/knee/velocity_model", knee_velocity_model_, nan);
        register_output(
            "/wheel_leg/identification/selected/inner_knee_measured_deg", knee_inner_measured_,
            nan);
        register_output(
            "/wheel_leg/identification/selected/inner_knee_target_deg", knee_inner_target_, nan);
        for (std::size_t i = 0; i < wheel_speed_target_.size(); ++i)
            register_output(
                std::string{"/wheel_leg/"} + (i == 0 ? "left_wheel" : "right_wheel")
                    + "/control_velocity",
                wheel_speed_target_[i], 0.0);
    }

    void before_updating() override {
        if (rl_pd_)
            RCLCPP_INFO(get_logger(), "RL_PD: PC recomputes from fresh feedback 1000 Hz, target %.0f Hz; "
                        "Kp=[%.3f,%.3f] Kd=[%.3f,%.3f]; no integral/velocity/gravity feedforward",
                        1000.0 / reference_ticks_,
                        pd_kp_[2 * side_], pd_kp_[2 * side_ + 1],
                        pd_kd_[2 * side_], pd_kd_[2 * side_ + 1]);
        else
            RCLCPP_INFO(get_logger(), "MIT position/velocity PI cascade: 1000 Hz; no 5-tick torque hold");
        RCLCPP_INFO(
            get_logger(), "%s identification configured for %s hip + auxiliary knee only",
            stage_ == ExperimentStage::kHold    ? "HOLD"
            : stage_ == ExperimentStage::kProbe ? "PROBE"
                                                : "TRAJECTORY",
            side_ == 0 ? "left" : "right");
        if (multiband_enabled_)
            RCLCPP_INFO(get_logger(), "MULTIBAND_CHIRP: measured initial shape, second shape shift <= %.3f rad; "
                        "six pose/shape blocks, common+differential %.2f..%.2f Hz / %.2f..%.2f Hz, "
                        "paired opposite-axis relative motion, held-out multisines; fixed chassis",
                        multiband_.shape_offset, multiband_.common_hz.front(), multiband_.common_hz.back(),
                        multiband_.relative_hz.front(), multiband_.relative_hz.back());
        else if (sweep_enabled_)
            RCLCPP_INFO(get_logger(), "ROTATION_CHIRP: paired 360-deg outward/return grids, "
                        "common +/-%.1f deg %.2f..%.2f Hz, relative +/-%.3f rad %.2f..%.2f Hz; "
                        "fixed chassis, gravity and gas springs retained",
                        sweep_.common_amplitude * 180 / std::numbers::pi,
                        sweep_.common_hz[0], sweep_.common_hz[1], sweep_.relative_amplitude,
                        sweep_.relative_hz[0], sweep_.relative_hz[1]);
        if (multiband_enabled_ && multiband_.load_offset > 0)
            RCLCPP_INFO(get_logger(), "SPRING_LOADED_PD: paired reference loading <= %.3f rad in "
                        "<=0.05 rad stages; validation relative scale %.1f; installed gas springs "
                        "and gravity retained, motor difference is not measured knee angle",
                        multiband_.load_offset, multiband_.validation_relative_scale);
        if (stage_ == ExperimentStage::kProbe)
            RCLCPP_INFO(
                get_logger(), "PROBE runtime speed/braking/tracking estimates are diagnostic; "
                              "measured drive-difference policy=%s (not physical inner-knee angle); "
                              "reference/initial-pose checks, root bounds, feedback and torque caps remain active",
                probe_delta_diagnostic_ ? "diagnostic" : "stop");
    }

    void update() override {
        zero_commands();
        *hip_angle_model_ = std::numeric_limits<double>::quiet_NaN();
        *knee_angle_model_ = std::numeric_limits<double>::quiet_NaN();
        *hip_velocity_model_ = std::numeric_limits<double>::quiet_NaN();
        *knee_velocity_model_ = std::numeric_limits<double>::quiet_NaN();
        *knee_inner_measured_ = std::numeric_limits<double>::quiet_NaN();
        if (*phase_ != 2)
            *knee_inner_target_ = std::numeric_limits<double>::quiet_NaN();
        if (*phase_ != 2)
            zero_diagnostics();
        const auto now = *timestamp_;
        const auto tick = *tick_;
        using rmcs_msgs::Switch;
        const auto left = *switch_left_, right = *switch_right_;
        const bool down = left == Switch::DOWN && right == Switch::DOWN;
        const bool middle = left == Switch::MIDDLE && right == Switch::MIDDLE;
        // Operator stop/reset must work even with stale motor feedback or a
        // broken executor clock. Hardware independently gates on the DR16 too.
        if (*dr16_fresh_ && down) {
            reset_on_both_down();
            return;
        }
        if (!*dr16_fresh_ || !middle) {
            if (*phase_ == 1 || *phase_ == 2)
                fail(3, "Remote stale or switches not both middle");
            have_clock_ = false;
            return;
        }
        // A held enable switch must not silently restart a failed/completed run.
        if (*phase_ == -1 || *phase_ == 3)
            return;
        if (!std::isfinite(*update_rate_) || *update_rate_ < 900 || *update_rate_ > 1100) {
            fail(1, "Executor must run at 1000 Hz");
            return;
        }
        if (have_clock_) {
            const double gap = std::chrono::duration<double>(now - previous_time_).count();
            if (tick != previous_tick_ + 1 || gap <= 0 || gap > max_tick_gap_s_) {
                RCLCPP_ERROR(get_logger(), "Timing discontinuity: tick %zu -> %zu, interval %.3f ms, limit %.3f ms",
                             previous_tick_, tick, gap * 1000, max_tick_gap_s_ * 1000);
                fail(2, tick != previous_tick_ + 1 ? "Executor update counter discontinuity"
                        : gap <= 0 ? "Executor clock did not advance"
                                   : "Executor interval exceeds configured timing budget");
                return;
            }
        }
        have_clock_ = true;
        previous_tick_ = tick;
        previous_time_ = now;

        if (*phase_ == 0) {
            *phase_ = 1;
            wait_start_ = now;
            RCLCPP_INFO(get_logger(), "Both-middle: preparing selected-side MIT enable");
        }
        if (*phase_ == 1
            && std::chrono::duration<double>(now - wait_start_).count() > ready_timeout_s_) {
            fail(18, "Selected DM did not become ready / preflight timed out");
            return;
        }

        if (const int feedback_fault = feedback_failure_code(); feedback_fault != 0) {
            model_phase_initialized_.fill(false);
            // Startup may precede the first disabled-drive feedback poll. Wait
            // with zero torque, but latch feedback loss once enable was requested.
            if (*phase_ == 1 && !enable_started_)
                return;
            fail(feedback_fault, "Missing, stale, future, or nonfinite motor/IMU feedback");
            return;
        }
        Eigen::Vector4d measured = Eigen::Vector4d::Zero();
        Eigen::Vector4d speed = Eigen::Vector4d::Zero();
        std::array<int, 4> statuses{}, faults{};
        for (std::size_t i = 0; i < 4; ++i) {
            const double phase = model_angle_from_api(
                *angle_[i], limits_.sign[i], limits_.offset[i], phase_api_angle_);
            measured[static_cast<Eigen::Index>(i)] =
                phase_api_angle_ && model_phase_initialized_[i]
                    ? unwrap_model_phase(phase, previous_model_angle_[i])
                    : phase;
            speed[static_cast<Eigen::Index>(i)] = limits_.sign[i] * *velocity_[i];
            if (!std::isfinite(*measured_max_torque_[i])
                || *measured_max_torque_[i] < limits_.max_torque[i]) {
                fail(5, "Configured torque exceeds live motor limit");
                return;
            }
            statuses[i] = *status_[i];
            faults[i] = *fault_[i];
        }
        if (phase_api_angle_) {
            for (std::size_t side = 0; side < 2; ++side) {
                const auto hip = static_cast<Eigen::Index>(2 * side);
                const auto knee = hip + 1;
                if (!model_phase_initialized_[2 * side + 1])
                    measured[knee] = align_auxiliary_to_pair_branch(
                        measured[knee], measured[hip], limits_.spring_min[side],
                        limits_.spring_max[side]);
            }
            for (std::size_t i = 0; i < 4; ++i) {
                previous_model_angle_[i] = measured[static_cast<Eigen::Index>(i)];
                model_phase_initialized_[i] = true;
            }
        }
        *hip_angle_model_ = measured[static_cast<Eigen::Index>(2 * side_)];
        *knee_angle_model_ = measured[static_cast<Eigen::Index>(2 * side_ + 1)];
        *hip_velocity_model_ = speed[static_cast<Eigen::Index>(2 * side_)];
        *knee_velocity_model_ = speed[static_cast<Eigen::Index>(2 * side_ + 1)];
        if (!motor_states_safe(
                side_, statuses, faults, *phase_ == 2, *phase_ == 0 || *phase_ == 1)) {
            fail(6, "Motor fault, torque drive disabled, or parked side enabled");
            return;
        }
        if (stage_ == ExperimentStage::kProbe) {
            const auto base = static_cast<Eigen::Index>(2 * side_);
            const double delta = measured[base + 1] - measured[base];
            const bool observe_delta = probe_delta_diagnostic_ && *phase_ == 2;
            const double delta_min = limits_.spring_min[side_] + limits_.spring_margin;
            const double delta_max = limits_.spring_max[side_] - limits_.spring_margin;
            if (const auto fault = check_probe_pair(
                    limits_, side_, {measured[base], measured[base + 1]},
                    {speed[base], speed[base + 1]}, false, !observe_delta);
                fault != PairFault::kNone) {
                RCLCPP_ERROR(get_logger(), "Probe coordinate check %d: q=[%.6f, %.6f] rad, "
                             "drive_delta=%.6f rad, configured delta interval=(%.6f, %.6f); "
                             "drive delta is not measured physical inner-knee angle",
                             static_cast<int>(fault), measured[base], measured[base + 1],
                             delta, delta_min, delta_max);
                fail(100 + static_cast<int>(fault), "Measured drive-coordinate admission failed");
                return;
            }
            if (observe_delta && (delta <= delta_min || delta >= delta_max)
                && !probe_delta_warning_emitted_) {
                RCLCPP_WARN(get_logger(), "Observed drive_delta=%.6f rad outside configured "
                            "proxy interval=(%.6f, %.6f); physical inner-knee angle is not measured. "
                            "Continuing the unchanged reference and recording feedback (diagnostic policy)",
                            delta, delta_min, delta_max);
                probe_delta_warning_emitted_ = true;
            }
            const auto estimate = check_probe_pair(
                limits_, side_, {measured[base], measured[base + 1]},
                {speed[base], speed[base + 1]});
            if (estimate != PairFault::kNone && estimate != PairFault::kSpringLimit
                && !probe_envelope_warning_emitted_[static_cast<std::size_t>(estimate)]) {
                RCLCPP_WARN(
                    get_logger(),
                    "Probe motion estimate %d exceeded (5=speed, 6=stopping distance); "
                    "continuing planned reference with torque cap; estimate is not identified",
                    static_cast<int>(estimate));
                probe_envelope_warning_emitted_[static_cast<std::size_t>(estimate)] = true;
            }
            // At an old branch boundary the probe only requests inward knee
            // motion. Observe small outward drift without inventing a new stop.
            if (probe_plan_ && probe_inward_direction_ != 0
                && probe_inward_direction_ * (delta - probe_start_delta_) < -0.004
                && !probe_outward_warning_emitted_) {
                RCLCPP_WARN(
                    get_logger(), "Probe knee drifted outward from its start; "
                                  "continuing while measured geometric bounds hold");
                probe_outward_warning_emitted_ = true;
            }
        } else {
            for (std::size_t side_index = 0; side_index < 2; ++side_index) {
                const auto base = static_cast<Eigen::Index>(2 * side_index);
                const auto fault = check_pair(
                    limits_, luts_[side_index], side_index, {measured[base], measured[base + 1]},
                    {speed[base], speed[base + 1]});
                if (fault != PairFault::kNone) {
                    fail(
                        100 + static_cast<int>(fault),
                        "Measured coupled pair outside safety envelope");
                    return;
                }
            }
        }
        const auto selected = static_cast<Eigen::Index>(2 * side_);
        if (stage_ != ExperimentStage::kProbe)
            *knee_inner_measured_ =
                luts_[side_].beta_from_delta(measured[selected + 1] - measured[selected]) * 180.0
                / std::numbers::pi;
        const auto other = static_cast<Eigen::Index>(2 * (1 - side_));
        if (std::abs(speed[other]) > other_side_speed_limit_
            || std::abs(speed[other + 1]) > other_side_speed_limit_) {
            if (stage_ != ExperimentStage::kProbe) {
                fail(17, "Unpowered opposite leg is moving");
                return;
            }
            if (!probe_parked_warning_emitted_) {
                RCLCPP_WARN(get_logger(), "Disabled opposite leg moved; continuing probe");
                probe_parked_warning_emitted_ = true;
            }
        }
        if (*phase_ != 2)
            *reference_model_ = measured;

        *enable_request_ = true;
        enable_started_ = true;
        if (*phase_ == 1) {
            // The hardware may clear a fault on this pair, but must not send
            // enable until both drives report fresh fault-free disabled feedback.
            *clear_error_request_ = true;
            if (((stage_ == ExperimentStage::kTrajectory && planner_)
                 || (stage_ == ExperimentStage::kProbe && probe_plan_))
                && (!*dm_control_ready_ || *status_[2 * side_] != 1
                    || *status_[2 * side_ + 1] != 1)) {
                fail(29, "Selected torque drive lost readiness during preflight");
                return;
            }
            if (!*dm_control_ready_ || *status_[2 * side_] != 1 || *status_[2 * side_ + 1] != 1)
                return;
            if (stage_ == ExperimentStage::kHold) {
                try {
                    std::array<double, 4> current{}, current_speed{};
                    for (std::size_t i = 0; i < 4; ++i) {
                        current[i] = measured[static_cast<Eigen::Index>(i)];
                        current_speed[i] = speed[static_cast<Eigen::Index>(i)];
                    }
                    hold_plan_.emplace(
                        limits_, luts_, side_, current, current_speed, hold_test_duration_s_);
                    parked_reference_ = measured;
                } catch (const std::exception& error) {
                    fail(19, error.what());
                    return;
                }
                *phase_ = 2;
                run_start_ = now;
                last_control_time_ = now;
                last_measured_speed_ = speed;
                have_measured_speed_ = true;
                integral_.fill(0.0);
                RCLCPP_INFO(get_logger(), "Selected-side MIT ready; holding measured pose");
            } else if (stage_ == ExperimentStage::kProbe) {
                if (!probe_plan_) {
                    try {
                        const auto base = static_cast<Eigen::Index>(2 * side_);
                        probe_start_delta_ = measured[base + 1] - measured[base];
                        probe_inward_direction_ =
                            probe_inward_direction(limits_, side_, probe_start_delta_);
                        probe_opening_checked_ = false;
                        const std::array initial{measured[base], measured[base + 1]};
                        if (multiband_enabled_)
                            probe_plan_.emplace(
                                std::in_place_type<PairMultibandPlan>, multiband_, initial,
                                limits_.spring_min[side_] + limits_.spring_margin,
                                limits_.spring_max[side_] - limits_.spring_margin);
                        else if (sweep_enabled_)
                            probe_plan_.emplace(
                                std::in_place_type<PairSweepPlan>, sweep_, initial,
                                limits_.spring_min[side_] + limits_.spring_margin,
                                limits_.spring_max[side_] - limits_.spring_margin);
                        else
                            probe_plan_.emplace(
                                std::in_place_type<PairProbePlan>, probe_, initial,
                                probe_inward_direction_);
                        preflight_steps_ =
                            static_cast<std::size_t>(std::ceil(probe_duration() / 0.001));
                        if (multiband_enabled_
                            && ready_timeout_s_ < 1.0 + std::ceil((preflight_steps_ + 1) / 128.0) * .001)
                            throw std::invalid_argument("ready_timeout_s cannot cover multiband preflight plus enable");
                        parked_reference_ = measured;
                    } catch (const std::exception& error) {
                        fail(19, error.what());
                        return;
                    }
                }
                for (std::size_t count = 0; count < 128 && preflight_index_ <= preflight_steps_;
                     ++count, ++preflight_index_) {
                    const auto sample = probe_sample(
                        probe_duration() * static_cast<double>(preflight_index_)
                        / static_cast<double>(preflight_steps_));
                    if (const auto fault = check_probe_reference(limits_, side_, sample);
                        fault != PairFault::kNone) {
                        fail(200 + static_cast<int>(fault), "Probe preflight exceeds motor limits");
                        return;
                    }
                }
                if (preflight_index_ <= preflight_steps_)
                    return;
                *phase_ = 2;
                run_start_ = now;
                last_control_time_ = now;
                last_measured_speed_ = speed;
                have_measured_speed_ = true;
                integral_.fill(0.0);
                RCLCPP_INFO(
                    get_logger(), "Measured motor-pair %s preflight passed; starting %s (%.1f s)",
                    multiband_enabled_ ? "multiband/chirp" : sweep_enabled_ ? "rotation/chirp" : "probe",
                    rl_pd_ ? "RL PD" : "cascade",
                    probe_duration());
            } else {
                if (!planner_) {
                    try {
                        const auto base = static_cast<Eigen::Index>(2 * side_);
                        planner_ = std::make_unique<PairPlanner>(
                            trajectory_, luts_[side_], limits_.beta_margin, measured[base],
                            measured[base + 1] - measured[base]);
                        const double highest_frequency = *std::max_element(
                            trajectory_.frequencies_hz.begin(), trajectory_.frequencies_hz.end());
                        const double step = std::min(0.001, 1.0 / (64 * highest_frequency));
                        preflight_steps_ =
                            static_cast<std::size_t>(std::ceil(planner_->duration() / step));
                        parked_reference_ = measured;
                    } catch (const std::exception& error) {
                        fail(19, error.what());
                        return;
                    }
                }
                // Bounded work per 1 kHz tick; zero effort while checking the entire path.
                for (std::size_t count = 0; count < 128 && preflight_index_ <= preflight_steps_;
                     ++count, ++preflight_index_) {
                    try {
                        const auto sample = planner_->at(
                            planner_->duration() * static_cast<double>(preflight_index_)
                            / static_cast<double>(preflight_steps_));
                        if (const auto fault =
                                check_reference(limits_, luts_[side_], side_, sample);
                            fault != PairFault::kNone) {
                            fail(
                                200 + static_cast<int>(fault),
                                "Preflight path exceeds mechanical/torque limits");
                            return;
                        }
                    } catch (const std::exception& error) {
                        fail(19, error.what());
                        return;
                    }
                }
                if (preflight_index_ <= preflight_steps_)
                    return;
                *phase_ = 2;
                run_start_ = now;
                last_control_time_ = now;
                last_measured_speed_ = speed;
                have_measured_speed_ = true;
                integral_.fill(0.0);
                RCLCPP_INFO(
                    get_logger(),
                    "Measured current-pose trajectory preflight passed; starting 1 kHz cascade");
            }
        }

        if (!*dm_control_ready_ || *status_[2 * side_] != 1 || *status_[2 * side_ + 1] != 1) {
            fail(29, "Selected-side MIT torque drive no longer ready");
            return;
        }
        const double elapsed = std::chrono::duration<double>(now - run_start_).count();
        if (!std::isfinite(elapsed) || elapsed < 0) {
            fail(2, "Invalid experiment elapsed time");
            return;
        }
        bool finished = false;
        if (stage_ == ExperimentStage::kHold)
            finished = hold_plan_->finished(elapsed);
        else if (stage_ == ExperimentStage::kProbe)
            finished = elapsed >= probe_duration();
        else
            finished = elapsed >= planner_->duration();
        if (finished) {
            *phase_ = 3;
            *segment_id_ = -1;
            *segment_role_ = 2;
            *segment_waveform_ = 0;
            *enable_request_ = false;
            *clear_error_request_ = false;
            held_torque_model_.fill(0.0);
            integral_.fill(0.0);
            last_segment_id_ = -1;
            planner_.reset();
            hold_plan_.reset();
            probe_plan_.reset();
            probe_inward_direction_ = 0;
            probe_opening_checked_ = false;
            zero_diagnostics();
            RCLCPP_INFO(
                get_logger(), "Identification %s complete; disabling drive",
                stage_ == ExperimentStage::kHold    ? "HOLD"
                : stage_ == ExperimentStage::kProbe ? "PROBE"
                                                    : "TRAJECTORY");
            return;
        }
        const bool opening_pending = stage_ == ExperimentStage::kProbe && !sweep_enabled_
                                  && probe_inward_direction_ != 0 && !probe_opening_checked_;
        if (opening_pending && elapsed >= probe_.hold_s * 2 + probe_.move_s) {
            const auto base = static_cast<Eigen::Index>(2 * side_);
            const double delta = measured[base + 1] - measured[base];
            if (!probe_has_interior_room(
                    probe_inward_direction_, probe_start_delta_, delta,
                    probe_min_interior_delta_)) {
                RCLCPP_WARN(
                    get_logger(), "Probe opening progress below diagnostic target; "
                                  "continuing while measured geometric bounds hold");
            }
            probe_opening_checked_ = true;
        }
        // Both laws recompute from the latest feedback every 1 kHz tick.
        // The independently sampled reference must not decimate the PD loop.
        try {
            update_closed_loop(now, elapsed, measured, speed);
        } catch (const std::exception& error) {
            fail(19, error.what());
            return;
        }
        if (*phase_ == -1)
            return;
        const auto torques = selected_torque_api(side_, limits_, held_torque_model_);
        for (std::size_t i = 0; i < command_torque_.size(); ++i)
            *command_torque_[i] = torques[i];
    }

private:
    static constexpr std::array kAxisNames{"left_hip_joint",   "left_knee_joint", "right_hip_joint",
                                           "right_knee_joint", "left_wheel",      "right_wheel"};

    template <std::size_t N>
    void load_array(const std::string& name, std::array<double, N>& array) {
        const auto values = get_parameter(name).as_double_array();
        if (values.size() != N)
            throw std::invalid_argument(
                name + " requires " + std::to_string(N) + " measured values");
        std::copy(values.begin(), values.end(), array.begin());
    }

    void zero_commands() {
        for (auto& torque : command_torque_)
            *torque = std::numeric_limits<double>::quiet_NaN();
        *enable_request_ = false;
        *clear_error_request_ = false;
    }

    void reset_on_both_down() {
        if (*phase_ != 0) {
            RCLCPP_INFO(get_logger(), "Both-down: release torque, disable and reset experiment");
            *repetition_id_output_ = ++repetition_id_;
        }
        *phase_ = 0;
        *failure_reason_ = 0;
        *segment_id_ = -1;
        *knee_inner_target_ = std::numeric_limits<double>::quiet_NaN();
        held_torque_model_.fill(0.0);
        integral_.fill(0.0);
        last_reference_tick_ = 0;
        planner_.reset();
        hold_plan_.reset();
        probe_plan_.reset();
        probe_inward_direction_ = 0;
        probe_opening_checked_ = false;
        preflight_index_ = 0;
        last_segment_id_ = -1;
        have_measured_speed_ = false;
        acceleration_warning_emitted_.fill(false);
        probe_envelope_warning_emitted_.fill(false);
        probe_tracking_warning_emitted_.fill(false);
        probe_outward_warning_emitted_ = false;
        probe_parked_warning_emitted_ = false;
        probe_delta_warning_emitted_ = false;
        timing_gap_warning_emitted_ = false;
        have_clock_ = false;
        enable_started_ = false;
        model_phase_initialized_.fill(false);
        zero_diagnostics();
    }

    void zero_diagnostics() {
        *segment_role_ = 2;
        *segment_waveform_ = 0;
        *reference_velocity_model_ = Eigen::Vector4d::Zero();
        *velocity_target_model_ = Eigen::Vector4d::Zero();
        *position_error_model_ = Eigen::Vector4d::Zero();
        *speed_error_model_ = Eigen::Vector4d::Zero();
        *torque_preclip_model_ = Eigen::Vector4d::Zero();
        *torque_preclip_api_ =
            Eigen::Matrix<double, 6, 1>::Constant(std::numeric_limits<double>::quiet_NaN());
        *torque_integral_model_ = Eigen::Vector4d::Zero();
        *torque_gravity_ff_model_ = Eigen::Vector4d::Zero();
    }

    int feedback_failure_code() const {
        const auto now = Clock::now().time_since_epoch();
        const auto now_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(now).count();
        if (now_ns < 0)
            return 80;
        for (std::size_t i = 0; i < feedback_ns_.size(); ++i) {
            const auto stamp = *feedback_ns_[i];
            if (stamp == 0)
                return 40 + static_cast<int>(i);
            if (stamp > static_cast<std::uint64_t>(now_ns))
                return 50 + static_cast<int>(i);
            if (static_cast<double>(static_cast<std::uint64_t>(now_ns) - stamp) * 1e-9
                > feedback_timeout_s_)
                return 60 + static_cast<int>(i);
            if (!std::isfinite(*angle_[i]) || !std::isfinite(*velocity_[i]))
                return 70 + static_cast<int>(i);
        }
        if (!*feedback_fresh_) {
            const auto stamp = *imu_feedback_ns_;
            if (!stamp || stamp > static_cast<std::uint64_t>(now_ns)
                || now_ns - static_cast<std::int64_t>(stamp) >= 50'000'000)
                return 81;
            return 80;
        }
        return 0;
    }

    bool check_tracking(std::size_t axis, double position_error, double speed_error) {
        if (!std::isfinite(position_error) || !std::isfinite(speed_error)) {
            fail(30, "Nonfinite tracking error");
            return false;
        }
        if (std::abs(position_error) <= max_position_error_[axis]
            && std::abs(speed_error) <= max_velocity_error_[axis])
            return true;
        if (stage_ != ExperimentStage::kProbe) {
            fail(30, "Measured tracking overshoot");
            return false;
        }
        if (!probe_tracking_warning_emitted_[axis]) {
            RCLCPP_WARN(
                get_logger(), "%s probe tracking error position=%.4f rad, speed=%.4f rad/s; "
                              "continuing with torque cap (diagnostic only)",
                kAxisNames[axis], position_error, speed_error);
            probe_tracking_warning_emitted_[axis] = true;
        }
        return true;
    }

    void update_closed_loop(
        Clock::time_point now, double elapsed, const Eigen::Vector4d& measured,
        const Eigen::Vector4d& speed) {
        const double dt = std::chrono::duration<double>(now - last_control_time_).count();
        if (!std::isfinite(dt) || dt < 0 || dt > max_tick_gap_s_) {
            fail(31, "Cascade interval exceeds configured timing budget");
            return;
        }
        // In the multiband experiment, do not extrapolate the newest velocity
        // error across missed feedback cycles. Retain the load-holding integral,
        // advance the reference to the current executor time, and update once.
        // The next normal tick resumes integration; no catch-up torque burst.
        const bool missed_cycles = !rl_pd_ && multiband_enabled_ && dt > 2.5 / *update_rate_;
        const double integral_dt = missed_cycles ? 0.0 : dt;
        if (missed_cycles && !timing_gap_warning_emitted_) {
            RCLCPP_WARN(get_logger(), "Multiband timing gap %.3f ms within %.3f ms budget; "
                        "holding integral for this update, advancing reference without catch-up cycles",
                        dt * 1000, max_tick_gap_s_ * 1000);
            timing_gap_warning_emitted_ = true;
        }
        if (!rl_pd_ || last_reference_tick_ == 0 || *tick_ - last_reference_tick_ >= reference_ticks_) {
            if (stage_ == ExperimentStage::kHold)
                held_reference_ = hold_plan_->at(elapsed);
            else if (stage_ == ExperimentStage::kProbe)
                held_reference_ = probe_sample(elapsed);
            else
                held_reference_ = planner_->at(elapsed);
            last_reference_tick_ = *tick_;
        }
        const auto& sample = held_reference_;
        *knee_inner_target_ = sample.beta * 180.0 / std::numbers::pi;
        PairFault fault;
        if (stage_ == ExperimentStage::kHold)
            fault = check_pair(limits_, luts_[side_], side_, sample.position, sample.velocity);
        else if (stage_ == ExperimentStage::kProbe)
            fault = check_probe_reference(limits_, side_, sample);
        else
            fault = check_reference(limits_, luts_[side_], side_, sample);
        if (fault != PairFault::kNone) {
            fail(300 + static_cast<int>(fault), "Running reference outside preflight bounds");
            return;
        }
        const auto base = static_cast<Eigen::Index>(2 * side_);
        *reference_model_ = parked_reference_;
        *reference_velocity_model_ = Eigen::Vector4d::Zero();
        *velocity_target_model_ = Eigen::Vector4d::Zero();
        *position_error_model_ = Eigen::Vector4d::Zero();
        *speed_error_model_ = Eigen::Vector4d::Zero();
        *torque_preclip_model_ = Eigen::Vector4d::Zero();
        *torque_integral_model_ = Eigen::Vector4d::Zero();
        *torque_gravity_ff_model_ = Eigen::Vector4d::Zero();
        for (std::size_t j = 0; j < 2; ++j) {
            const auto i = static_cast<std::size_t>(base) + j;
            (*reference_model_)[static_cast<Eigen::Index>(i)] = sample.position[j];
            (*reference_velocity_model_)[static_cast<Eigen::Index>(i)] = sample.velocity[j];
            if (have_measured_speed_ && dt > 0 && !acceleration_warning_emitted_[j]) {
                // This threshold has not been identified on the suspended leg.
                // Differencing quantized asynchronous velocity samples is only
                // diagnostic; it must not latch an otherwise valid experiment.
                const double acceleration =
                    (speed[static_cast<Eigen::Index>(i)]
                     - last_measured_speed_[static_cast<Eigen::Index>(i)])
                    / dt;
                if (std::abs(acceleration) > max_measured_acceleration_[i]) {
                    RCLCPP_WARN(
                        get_logger(),
                        "%s measured acceleration %.3f rad/s^2 exceeds diagnostic threshold "
                        "%.3f; continuing (logged once per axis per run)",
                        kAxisNames[i], acceleration, max_measured_acceleration_[i]);
                    acceleration_warning_emitted_[j] = true;
                }
            }
            const auto result = rl_pd_ ? pd_step(
                sample.position[j], measured[static_cast<Eigen::Index>(i)],
                speed[static_cast<Eigen::Index>(i)], pd_kp_[i], pd_kd_[i],
                std::min(limits_.max_torque[i], *measured_max_torque_[i])) : cascade_step(
                sample.position[j], sample.velocity[j], measured[static_cast<Eigen::Index>(i)],
                speed[static_cast<Eigen::Index>(i)], kp_position_[i], kp_velocity_[i],
                ki_velocity_[i], limits_.max_speed[i],
                std::min(limits_.max_torque[i], *measured_max_torque_[i]), integral_limit_[i], integral_dt,
                integral_[j]);
            (*velocity_target_model_)[static_cast<Eigen::Index>(i)] = result.velocity_target;
            (*position_error_model_)[static_cast<Eigen::Index>(i)] = result.position_error;
            (*speed_error_model_)[static_cast<Eigen::Index>(i)] = result.speed_error;
            const double gravity_ff = gravity_feedforward_[i];
            const double requested = result.preclip + gravity_ff;
            (*torque_gravity_ff_model_)[static_cast<Eigen::Index>(i)] = gravity_ff;
            (*torque_preclip_model_)[static_cast<Eigen::Index>(i)] = requested;
            (*torque_preclip_api_)[static_cast<Eigen::Index>(i)] = limits_.sign[i] * requested;
            (*torque_integral_model_)[static_cast<Eigen::Index>(i)] = result.integral_torque;
            if (!std::isfinite(result.torque) || !std::isfinite(result.preclip)) {
                fail(30, "Nonfinite cascade output");
                return;
            }
            if (!check_tracking(i, result.position_error, result.speed_error))
                return;
            const double torque_cap = std::min(limits_.max_torque[i], *measured_max_torque_[i]);
            held_torque_model_[j] = std::clamp(requested, -torque_cap, torque_cap);
        }
        last_control_time_ = now;
        last_measured_speed_ = speed;
        *segment_id_ = sample.segment_id;
        *segment_role_ = sample.validation ? 1 : 0;
        *segment_waveform_ = sample.waveform;
        if (multiband_enabled_ && sample.segment_id != last_segment_id_) {
            const auto& plan = std::get<PairMultibandPlan>(*probe_plan_);
            const auto& segment = plan.segments().at(static_cast<std::size_t>(sample.segment_id));
            RCLCPP_INFO(get_logger(), "Multiband segment %d: %s, %.1f s, validation=%d, "
                        "delta_ref=%.4f measured=%.4f, relative low-band amplitude=%.4f rad",
                        sample.segment_id, segment.name.c_str(), segment.duration_s, sample.validation,
                        segment.from[1], measured[base + 1] - measured[base],
                        plan.relative_amplitude(multiband_.relative_amplitude[0], segment.from[1]));
        }
        last_segment_id_ = sample.segment_id;
    }

    void fail(int code, const char* message) {
        if (*phase_ != -1)
            RCLCPP_ERROR(get_logger(), "Identification stopped (%d): %s", code, message);
        *phase_ = -1;
        *knee_inner_target_ = std::numeric_limits<double>::quiet_NaN();
        *failure_reason_ = code;
        *segment_id_ = -1;
        *segment_role_ = 2;
        *segment_waveform_ = 0;
        *enable_request_ = false;
        *clear_error_request_ = false;
        held_torque_model_.fill(0.0);
        integral_.fill(0.0);
        last_segment_id_ = -1;
        planner_.reset();
        hold_plan_.reset();
        probe_plan_.reset();
        probe_inward_direction_ = 0;
        probe_opening_checked_ = false;
        preflight_index_ = 0;
        zero_commands();
        zero_diagnostics();
    }

    std::size_t side_ = 0;
    bool phase_api_angle_ = false;
    bool rl_pd_ = false;
    std::array<double, 4> pd_kp_{}, pd_kd_{};
    std::size_t reference_ticks_ = 20, last_reference_tick_ = 0;
    PairSample held_reference_{};
    ExperimentStage stage_ = ExperimentStage::kHold;
    double hold_test_duration_s_ = 0;
    PairLimits limits_;
    std::array<KneeLut, 2> luts_;
    PairTrajectoryConfig trajectory_;
    double probe_duration() const {
        return std::visit([](const auto& plan) { return plan.duration(); }, *probe_plan_);
    }

    PairSample probe_sample(double elapsed) const {
        return std::visit([elapsed](const auto& plan) { return plan.at(elapsed); }, *probe_plan_);
    }

    PairProbeConfig probe_;
    PairSweepConfig sweep_;
    bool sweep_enabled_ = false;
    PairMultibandConfig multiband_;
    bool multiband_enabled_ = false;
    bool probe_delta_diagnostic_ = false, probe_delta_warning_emitted_ = false;
    std::array<double, 4> kp_position_{}, kp_velocity_{}, ki_velocity_{}, integral_limit_{};
    std::array<double, 4> gravity_feedforward_{};
    std::array<double, 4> max_position_error_{}, max_velocity_error_{},
        max_measured_acceleration_{};
    double ready_timeout_s_ = 0, feedback_timeout_s_ = 0;
    double max_tick_gap_s_ = 0, other_side_speed_limit_ = 0;

    InputInterface<std::size_t> tick_;
    InputInterface<double> update_rate_;
    InputInterface<Clock::time_point> timestamp_;
    InputInterface<rmcs_msgs::Switch> switch_left_, switch_right_;
    InputInterface<bool> feedback_fresh_, dr16_fresh_, dm_control_ready_;
    InputInterface<std::uint64_t> imu_feedback_ns_;
    std::array<InputInterface<double>, 6> angle_, velocity_, measured_max_torque_;
    std::array<InputInterface<std::uint64_t>, 6> feedback_ns_;
    std::array<InputInterface<int>, 4> fault_, status_;
    std::array<OutputInterface<double>, 6> command_torque_;
    OutputInterface<bool> enable_request_;
    OutputInterface<bool> clear_error_request_;
    OutputInterface<Eigen::Vector4d> reference_model_, reference_velocity_model_;
    OutputInterface<Eigen::Vector4d> velocity_target_model_, position_error_model_,
        speed_error_model_;
    OutputInterface<Eigen::Vector4d> torque_preclip_model_, torque_integral_model_;
    OutputInterface<Eigen::Vector4d> torque_gravity_ff_model_;
    OutputInterface<Eigen::Matrix<double, 6, 1>> torque_preclip_api_;
    OutputInterface<int> phase_, segment_id_, selected_side_, failure_reason_;
    OutputInterface<std::uint8_t> segment_role_;
    OutputInterface<std::uint8_t> segment_waveform_;
    OutputInterface<std::uint32_t> repetition_id_output_;
    std::array<OutputInterface<double>, 2> wheel_speed_target_;
    OutputInterface<double> hip_angle_model_, knee_angle_model_;
    OutputInterface<double> hip_velocity_model_, knee_velocity_model_;
    OutputInterface<double> knee_inner_measured_, knee_inner_target_;

    bool have_clock_ = false, have_measured_speed_ = false;
    bool enable_started_ = false;
    std::size_t previous_tick_ = 0, preflight_index_ = 0, preflight_steps_ = 0;
    int last_segment_id_ = -1;
    std::uint32_t repetition_id_ = 0;
    Clock::time_point previous_time_{}, wait_start_{}, run_start_{}, last_control_time_{};
    Eigen::Vector4d parked_reference_ = Eigen::Vector4d::Zero();
    Eigen::Vector4d last_measured_speed_ = Eigen::Vector4d::Zero();
    std::array<bool, 2> acceleration_warning_emitted_{};
    std::array<bool, 9> probe_envelope_warning_emitted_{};
    std::array<bool, 4> probe_tracking_warning_emitted_{};
    bool probe_outward_warning_emitted_ = false;
    bool probe_parked_warning_emitted_ = false;
    bool timing_gap_warning_emitted_ = false;
    std::array<double, 4> previous_model_angle_{};
    std::array<bool, 4> model_phase_initialized_{};
    std::array<double, 2> integral_{}, held_torque_model_{};
    std::optional<HoldPlan> hold_plan_;
    std::optional<std::variant<PairProbePlan, PairSweepPlan, PairMultibandPlan>> probe_plan_;
    int probe_inward_direction_ = 0;
    double probe_start_delta_ = 0.0;
    double probe_min_interior_delta_ = 0.0;
    bool probe_opening_checked_ = false;
    std::unique_ptr<PairPlanner> planner_;
};

} // namespace rmcs_core::controller::identification

PLUGINLIB_EXPORT_CLASS(
    rmcs_core::controller::identification::WheelLegPairIdentificationController,
    rmcs_executor::Component)
