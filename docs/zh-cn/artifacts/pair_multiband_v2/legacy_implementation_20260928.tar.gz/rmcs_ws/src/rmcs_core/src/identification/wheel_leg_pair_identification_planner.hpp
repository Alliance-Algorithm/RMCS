#pragma once

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <numbers>
#include <stdexcept>
#include <string_view>
#include <utility>
#include <vector>

namespace rmcs_core::controller::identification {

// Beta is the measured inner-knee angle; delta is the measured auxiliary-drive minus hip angle.
// PCHIP preserves monotonicity and does not overshoot a measured spring-travel interval.
class KneeLut {
public:
    struct Value {
        double delta, slope, curvature;
    };

    KneeLut() = default;
    KneeLut(std::vector<double> beta_degrees, std::vector<double> delta) {
        if (beta_degrees.size() < 3 || beta_degrees.size() != delta.size())
            throw std::invalid_argument("Measured knee LUT requires at least three pairs");
        for (auto& beta : beta_degrees)
            beta *= std::numbers::pi / 180.0;
        const auto n = delta.size();
        if (beta_degrees.front() < kBetaMin || beta_degrees.back() > kBetaMax)
            throw std::invalid_argument(
                "Measured knee LUT must lie within this rig's physical 40 to 105 degrees");
        const double direction = delta.back() > delta.front() ? 1.0 : -1.0;
        std::vector<double> h(n - 1), secant(n - 1);
        for (std::size_t i = 0; i + 1 < n; ++i) {
            h[i] = beta_degrees[i + 1] - beta_degrees[i];
            secant[i] = (delta[i + 1] - delta[i]) / h[i];
            if (!std::isfinite(beta_degrees[i]) || !std::isfinite(beta_degrees[i + 1])
                || !std::isfinite(delta[i]) || !std::isfinite(h[i]) || h[i] <= 0.0
                || !std::isfinite(delta[i + 1]) || !std::isfinite(secant[i])
                || direction * secant[i] <= 0.0)
                throw std::invalid_argument("Knee LUT must be finite and strictly monotone");
        }
        slopes_.resize(n);
        const auto endpoint = [](double h0, double h1, double d0, double d1) {
            const double value = ((2 * h0 + h1) * d0 - h0 * d1) / (h0 + h1);
            return value * d0 <= 0 ? 0.0 : std::abs(value) > 3 * std::abs(d0) ? 3 * d0 : value;
        };
        slopes_.front() = endpoint(h[0], h[1], secant[0], secant[1]);
        slopes_.back() = endpoint(h[n - 2], h[n - 3], secant[n - 2], secant[n - 3]);
        for (std::size_t i = 1; i + 1 < n; ++i) {
            const double w1 = 2 * h[i] + h[i - 1], w2 = h[i] + 2 * h[i - 1];
            slopes_[i] = (w1 + w2) / (w1 / secant[i - 1] + w2 / secant[i]);
        }
        beta_ = std::move(beta_degrees);
        delta_ = std::move(delta);
    }

    [[nodiscard]] Value at(double beta) const {
        if (beta_.empty() || !std::isfinite(beta) || beta < beta_.front() || beta > beta_.back())
            throw std::out_of_range("Knee beta outside measured LUT");
        const auto upper = std::upper_bound(beta_.begin(), beta_.end(), beta);
        const std::size_t i = upper == beta_.end()
                                ? beta_.size() - 2
                                : static_cast<std::size_t>(upper - beta_.begin() - 1);
        const double h = beta_[i + 1] - beta_[i], u = (beta - beta_[i]) / h;
        const double a = 2 * delta_[i] - 2 * delta_[i + 1] + h * (slopes_[i] + slopes_[i + 1]);
        const double b = -3 * delta_[i] + 3 * delta_[i + 1] - h * (2 * slopes_[i] + slopes_[i + 1]);
        const double interpolated = ((a * u + b) * u + h * slopes_[i]) * u + delta_[i];
        return {
            std::clamp(
                interpolated, std::min(delta_[i], delta_[i + 1]),
                std::max(delta_[i], delta_[i + 1])),
            (3 * a * u * u + 2 * b * u + h * slopes_[i]) / h, (6 * a * u + 2 * b) / (h * h)};
    }

    [[nodiscard]] double beta_from_delta(double delta) const {
        if (beta_.empty() || !std::isfinite(delta)
            || delta < std::min(delta_.front(), delta_.back())
            || delta > std::max(delta_.front(), delta_.back()))
            throw std::out_of_range("Spring delta outside measured LUT");
        double lo = beta_.front(), hi = beta_.back();
        const bool increasing = delta_.back() > delta_.front();
        for (int i = 0; i < 48; ++i) {
            const double mid = (lo + hi) / 2;
            if ((at(mid).delta < delta) == increasing)
                lo = mid;
            else
                hi = mid;
        }
        return (lo + hi) / 2;
    }

    [[nodiscard]] double beta_min() const { return beta_.front(); }
    [[nodiscard]] double beta_max() const { return beta_.back(); }

    static constexpr double kBetaMin = 40.0 * std::numbers::pi / 180.0;
    // Real installed stop is 105 deg. The 110 deg training asset is not a
    // hardware limit and cannot be used to extend this identification path.
    static constexpr double kBetaMax = 105.0 * (std::numbers::pi / 180.0);

private:
    std::vector<double> beta_, delta_, slopes_;
};

struct PairLimits {
    // All joint arrays are ordered left hip, left auxiliary knee, right hip, right auxiliary knee.
    std::array<double, 4> sign{}, offset{}, root_min{}, root_max{}, max_speed{}, max_acceleration{},
        braking_acceleration{}, max_torque{}, inertia_bound{}, load_torque_bound{}, viscous_bound{};
    std::array<double, 2> spring_min{}, spring_max{};
    double joint_margin = 0.0, spring_margin = 0.0, beta_margin = 0.0;
};

// The earlier VEL driver exposed q = remainder(sign*angle_api + offset, 2*pi).
// Apply the offset BEFORE wrapping, or a real pose across the wrap seam will
// appear one complete revolution outside its calibrated model coordinates.
inline double model_angle_from_api(double api, double sign, double offset, bool phase_api) {
    const double model = sign * api + offset;
    return phase_api ? std::remainder(model, 2.0 * std::numbers::pi) : model;
}

// The thighs rotate continuously: +/-pi is only a phase seam, not a hard stop.
inline double unwrap_model_phase(double phase, double previous) {
    return previous + std::remainder(phase - previous, 2.0 * std::numbers::pi);
}

inline double align_auxiliary_to_pair_branch(
    double knee_phase, double hip, double delta_min, double delta_max) {
    const double middle = (delta_min + delta_max) / 2.0;
    const double displacement = hip + middle - knee_phase;
    const double revolutions = std::round(displacement / (2.0 * std::numbers::pi));
    return knee_phase + 2.0 * std::numbers::pi * revolutions;
}

enum class PairFault {
    kNone,
    kNonfinite,
    kRootLimit,
    kSpringLimit,
    kKneeLimit,
    kSpeed,
    kStoppingDistance,
    kAcceleration,
    kTorque
};

struct PairSample {
    std::array<double, 2> position{}, velocity{}, acceleration{};
    double beta = 0.0;
    int segment_id = -1;
    bool validation = false;
    std::uint8_t waveform = 0; // 0=dwell, 1=move, 2=multisine, 3=step, 4=triangle, 5=validate
};

enum class ExperimentStage { kHold, kProbe, kTrajectory };

inline ExperimentStage parse_experiment_stage(std::string_view stage) {
    if (stage == "hold")
        return ExperimentStage::kHold;
    if (stage == "probe")
        return ExperimentStage::kProbe;
    if (stage == "trajectory")
        return ExperimentStage::kTrajectory;
    throw std::invalid_argument("experiment_stage must be hold, probe or trajectory");
}

inline bool double_down_dwell_complete(
    std::chrono::steady_clock::time_point now, std::chrono::steady_clock::time_point down_since,
    double dwell_s) {
    return down_since != std::chrono::steady_clock::time_point{} && now >= down_since
        && std::chrono::duration<double>(now - down_since).count() >= dwell_s;
}

inline void validate_limits(const PairLimits& limits, bool require_trajectory_model = true) {
    const auto finite = [](double x) { return std::isfinite(x); };
    for (std::size_t i = 0; i < 4; ++i) {
        if (!finite(limits.sign[i]) || std::abs(limits.sign[i]) != 1.0 || !finite(limits.offset[i])
            || !finite(limits.root_min[i]) || !finite(limits.root_max[i])
            || limits.root_max[i] <= limits.root_min[i] || !finite(limits.max_speed[i])
            || limits.max_speed[i] <= 0 || !finite(limits.max_acceleration[i])
            || limits.max_acceleration[i] <= 0 || !finite(limits.braking_acceleration[i])
            || limits.braking_acceleration[i] <= 0
            || limits.braking_acceleration[i] > limits.max_acceleration[i]
            || !finite(limits.max_torque[i]) || limits.max_torque[i] <= 0
            || (require_trajectory_model
                && (!finite(limits.inertia_bound[i]) || limits.inertia_bound[i] <= 0
                    || !finite(limits.load_torque_bound[i]) || limits.load_torque_bound[i] < 0
                    || !finite(limits.viscous_bound[i]) || limits.viscous_bound[i] < 0)))
            throw std::invalid_argument("Invalid measured joint calibration or limits");
    }
    for (std::size_t side = 0; side < 2; ++side)
        if (!finite(limits.spring_min[side]) || !finite(limits.spring_max[side])
            || limits.spring_min[side] >= limits.spring_max[side])
            throw std::invalid_argument("Invalid measured spring travel");
    if (!finite(limits.joint_margin) || limits.joint_margin <= 0 || !finite(limits.spring_margin)
        || limits.spring_margin <= 0 || !finite(limits.beta_margin) || limits.beta_margin <= 0
        || 2 * limits.beta_margin >= KneeLut::kBetaMax - KneeLut::kBetaMin)
        throw std::invalid_argument("Positive physical boundary margins required");
}

inline bool motor_states_safe(
    std::size_t selected_side, const std::array<int, 4>& status, const std::array<int, 4>& fault,
    bool running, bool allow_selected_fault = false) {
    if (selected_side > 1)
        return false;
    for (std::size_t i = 0; i < status.size(); ++i) {
        if (i / 2 == selected_side && allow_selected_fault && status[i] >= 8 && status[i] <= 14
            && fault[i] == status[i] && status[2 * selected_side] != 1
            && status[2 * selected_side + 1] != 1)
            continue;
        if (fault[i] != 0 || (i / 2 != selected_side && status[i] != 0)
            || (i / 2 == selected_side && (status[i] < (running ? 1 : 0) || status[i] > 1)))
            return false;
    }
    return true;
}

inline PairFault check_pair(
    const PairLimits& limits, const KneeLut& lut, std::size_t side, const std::array<double, 2>& q,
    const std::array<double, 2>& dq) {
    if (side > 1 || !std::isfinite(q[0]) || !std::isfinite(q[1]) || !std::isfinite(dq[0])
        || !std::isfinite(dq[1]))
        return PairFault::kNonfinite;
    const double delta = q[1] - q[0];
    if (delta <= limits.spring_min[side] + limits.spring_margin
        || delta >= limits.spring_max[side] - limits.spring_margin)
        return PairFault::kSpringLimit;
    for (std::size_t j = 0; j < 2; ++j) {
        const auto i = 2 * side + j;
        if (q[j] <= limits.root_min[i] + limits.joint_margin
            || q[j] >= limits.root_max[i] - limits.joint_margin)
            return PairFault::kRootLimit;
    }
    double beta;
    try {
        beta = lut.beta_from_delta(delta);
    } catch (const std::out_of_range&) {
        return PairFault::kKneeLimit;
    }
    const double slope = lut.at(beta).slope;
    if (!std::isfinite(slope) || std::abs(slope) < 1e-9)
        return PairFault::kNonfinite;
    const double dbeta = (dq[1] - dq[0]) / slope;
    const double safe_min = std::max(KneeLut::kBetaMin, lut.beta_min()) + limits.beta_margin;
    const double safe_max = std::min(KneeLut::kBetaMax, lut.beta_max()) - limits.beta_margin;
    if (beta <= safe_min || beta >= safe_max)
        return PairFault::kKneeLimit;
    // Retain braking room before either the calibrated LUT edge or the physical hard stop.
    const double knee_brake =
        std::min(limits.braking_acceleration[2 * side], limits.braking_acceleration[2 * side + 1])
        * std::min(std::abs(slope), 1.0 / std::abs(slope));
    if (!std::isfinite(dbeta) || !std::isfinite(knee_brake) || knee_brake <= 0)
        return PairFault::kNonfinite;
    if (beta - safe_min < std::max(0.0, -dbeta) * std::max(0.0, -dbeta) / (2 * knee_brake)
        || safe_max - beta < std::max(0.0, dbeta) * std::max(0.0, dbeta) / (2 * knee_brake))
        return PairFault::kStoppingDistance;
    const double ddelta = dq[1] - dq[0];
    const double spring_brake =
        std::min(limits.braking_acceleration[2 * side], limits.braking_acceleration[2 * side + 1]);
    if (delta - limits.spring_min[side] - limits.spring_margin
            < std::pow(std::max(0.0, -ddelta), 2) / (2 * spring_brake)
        || limits.spring_max[side] - limits.spring_margin - delta
               < std::pow(std::max(0.0, ddelta), 2) / (2 * spring_brake))
        return PairFault::kStoppingDistance;
    for (std::size_t j = 0; j < 2; ++j) {
        const auto i = 2 * side + j;
        if (std::abs(dq[j]) > limits.max_speed[i])
            return PairFault::kSpeed;
        if (q[j] - limits.root_min[i] - limits.joint_margin
                < std::pow(std::max(0.0, -dq[j]), 2) / (2 * limits.braking_acceleration[i])
            || limits.root_max[i] - limits.joint_margin - q[j]
                   < std::pow(std::max(0.0, dq[j]), 2) / (2 * limits.braking_acceleration[i]))
            return PairFault::kStoppingDistance;
    }
    return PairFault::kNone;
}

inline PairFault check_reference(
    const PairLimits& limits, const KneeLut& lut, std::size_t side, const PairSample& sample) {
    if (const auto fault = check_pair(limits, lut, side, sample.position, sample.velocity);
        fault != PairFault::kNone)
        return fault;
    for (std::size_t j = 0; j < 2; ++j) {
        const auto i = 2 * side + j;
        const double acceleration = sample.acceleration[j];
        if (!std::isfinite(acceleration) || std::abs(acceleration) > limits.max_acceleration[i])
            return PairFault::kAcceleration;
        // Conservative identified upper bounds, not an invented nominal inertia/gravity model.
        if (limits.inertia_bound[i] * std::abs(acceleration)
                + limits.viscous_bound[i] * std::abs(sample.velocity[j])
                + limits.load_torque_bound[i]
            > limits.max_torque[i])
            return PairFault::kTorque;
    }
    return PairFault::kNone;
}

// The first motor-coordinate probe does not infer the physical knee angle from
// an unmeasured linkage table. Bound both independent roots and their relative
// motion on the old calibrated assembly branch instead.
inline PairFault check_probe_pair(
    const PairLimits& limits, std::size_t side, const std::array<double, 2>& q,
    const std::array<double, 2>& dq, bool check_dynamic_limits = true,
    bool check_drive_difference = true) {
    if (side > 1 || !std::isfinite(q[0]) || !std::isfinite(q[1]) || !std::isfinite(dq[0])
        || !std::isfinite(dq[1]))
        return PairFault::kNonfinite;
    const double delta = q[1] - q[0], delta_speed = dq[1] - dq[0];
    const double min = limits.spring_min[side] + limits.spring_margin;
    const double max = limits.spring_max[side] - limits.spring_margin;
    if (check_drive_difference && (delta <= min || delta >= max))
        return PairFault::kSpringLimit;
    for (std::size_t j = 0; j < 2; ++j) {
        const auto i = 2 * side + j;
        if (q[j] <= limits.root_min[i] + limits.joint_margin
            || q[j] >= limits.root_max[i] - limits.joint_margin)
            return PairFault::kRootLimit;
    }
    // Reference/initial-pose admission always checks the drive difference.
    // An explicit observation run may make that uncalibrated proxy diagnostic
    // after admission. Independent root bounds and finite data still apply.
    if (!check_dynamic_limits)
        return PairFault::kNone;
    const double brake =
        std::min(limits.braking_acceleration[2 * side], limits.braking_acceleration[2 * side + 1]);
    if (delta - min < std::pow(std::max(0.0, -delta_speed), 2) / (2 * brake)
        || max - delta < std::pow(std::max(0.0, delta_speed), 2) / (2 * brake))
        return PairFault::kStoppingDistance;
    for (std::size_t j = 0; j < 2; ++j) {
        const auto i = 2 * side + j;
        if (std::abs(dq[j]) > limits.max_speed[i])
            return PairFault::kSpeed;
        if (q[j] - limits.root_min[i] - limits.joint_margin
                < std::pow(std::max(0.0, -dq[j]), 2) / (2 * limits.braking_acceleration[i])
            || limits.root_max[i] - limits.joint_margin - q[j]
                   < std::pow(std::max(0.0, dq[j]), 2) / (2 * limits.braking_acceleration[i]))
            return PairFault::kStoppingDistance;
    }
    return PairFault::kNone;
}

inline PairFault
    check_probe_reference(const PairLimits& limits, std::size_t side, const PairSample& sample) {
    // Planned kinematics must fit geometry, speed and acceleration budgets.
    // An unidentified braking estimate cannot certify (or reject) this path.
    if (const auto fault = check_probe_pair(limits, side, sample.position, sample.velocity, false);
        fault != PairFault::kNone)
        return fault;
    for (std::size_t j = 0; j < 2; ++j)
        if (std::abs(sample.velocity[j]) > limits.max_speed[2 * side + j])
            return PairFault::kSpeed;
    for (std::size_t j = 0; j < 2; ++j)
        if (!std::isfinite(sample.acceleration[j])
            || std::abs(sample.acceleration[j]) > limits.max_acceleration[2 * side + j])
            return PairFault::kAcceleration;
    return PairFault::kNone;
}

// Select a one-sided knee excitation near either measured-difference boundary.
// A positive result increases q_aux-q_hip, a negative result decreases it.
inline int probe_inward_direction(const PairLimits& limits, std::size_t side, double delta) {
    if (side >= 2 || !std::isfinite(delta))
        throw std::invalid_argument("Invalid probe side or motor difference");
    constexpr double kBoundaryBand = 0.12;
    const double low = limits.spring_min[side] + limits.spring_margin;
    const double high = limits.spring_max[side] - limits.spring_margin;
    if (delta - low < kBoundaryBand)
        return 1;
    if (high - delta < kBoundaryBand)
        return -1;
    return 0;
}

inline bool probe_has_interior_room(
    int direction, double initial_delta, double measured_delta, double minimum_progress) {
    return direction == 0
        || ((direction == -1 || direction == 1) && std::isfinite(initial_delta)
            && std::isfinite(measured_delta) && std::isfinite(minimum_progress)
            && minimum_progress > 0
            && direction * (measured_delta - initial_delta) >= minimum_progress);
}

// Holds the exact measured model pose, without planning a move or allocating on the control path.
class HoldPlan {
public:
    HoldPlan(
        const PairLimits& limits, const std::array<KneeLut, 2>& luts, std::size_t side,
        const std::array<double, 4>& measured, const std::array<double, 4>& speed,
        double duration_s)
        : position_(measured)
        , side_(side)
        , duration_s_(duration_s) {
        if (side >= luts.size() || !std::isfinite(duration_s) || duration_s < 0.1
            || duration_s > 5.0)
            throw std::invalid_argument("Hold stage requires one side and 0.1-5 seconds");
        for (std::size_t pair = 0; pair < luts.size(); ++pair)
            if (check_pair(
                    limits, luts[pair], pair, {measured[2 * pair], measured[2 * pair + 1]},
                    {speed[2 * pair], speed[2 * pair + 1]})
                != PairFault::kNone)
                throw std::invalid_argument("Hold start lacks safe mechanical/braking margin");
        const std::size_t base = 2 * side;
        beta_ = luts[side].beta_from_delta(position_[base + 1] - position_[base]);
    }

    [[nodiscard]] double duration() const { return duration_s_; }
    [[nodiscard]] bool finished(double elapsed) const { return elapsed >= duration_s_; }

    [[nodiscard]] PairSample at(double elapsed) const {
        if (!std::isfinite(elapsed) || elapsed < 0 || finished(elapsed))
            throw std::out_of_range("Hold expired; disable drive");
        const auto base = 2 * side_;
        return {{position_[base], position_[base + 1]}, {0, 0}, {0, 0}, beta_, 0};
    }

    [[nodiscard]] const std::array<double, 4>& reference() const { return position_; }

private:
    std::array<double, 4> position_;
    std::size_t side_;
    double duration_s_, beta_ = 0;
};

struct PairProbeConfig {
    double common_amplitude = 0, knee_amplitude = 0, sine_common_amplitude = 0,
           sine_knee_amplitude = 0, move_s = 0, hold_s = 0, excite_s = 0, validation_s = 0;
    double gravity_hold_s = 0, step_amplitude = 0, step_rise_s = 0;
    double triangle_amplitude = 0, triangle_frequency_hz = 0, triangle_s = 0;
    std::array<double, 2> frequencies_hz{}, validation_frequencies_hz{};
};

// Motor-coordinate excitation relative to the measured pose. It requires no
// simulated inverse kinematics and never interprets motor difference as beta.
class PairProbePlan {
public:
    static void validate_config(const PairProbeConfig& config) {
        const auto positive = [](double value) { return std::isfinite(value) && value > 0; };
        const bool step_ready = positive(config.gravity_hold_s) && positive(config.step_amplitude)
                             && positive(config.step_rise_s);
        const bool triangle_ready = positive(config.triangle_amplitude)
                                 && positive(config.triangle_frequency_hz)
                                 && positive(config.triangle_s);
        if (!positive(config.common_amplitude) || !positive(config.knee_amplitude)
            || !positive(config.sine_common_amplitude) || !positive(config.sine_knee_amplitude)
            || config.sine_common_amplitude > config.common_amplitude
            || config.sine_knee_amplitude > config.knee_amplitude || !positive(config.move_s)
            || !positive(config.hold_s) || !positive(config.excite_s)
            || !positive(config.validation_s) || !positive(config.frequencies_hz[0])
            || !positive(config.frequencies_hz[1])
            || config.frequencies_hz[0] >= config.frequencies_hz[1]
            || config.frequencies_hz[1] > 3.0 || !positive(config.validation_frequencies_hz[0])
            || !positive(config.validation_frequencies_hz[1])
            || config.validation_frequencies_hz[0] >= config.validation_frequencies_hz[1]
            || config.validation_frequencies_hz[1] > 3.0 || !step_ready || !triangle_ready
            || config.step_amplitude > config.common_amplitude
            || config.triangle_amplitude > config.common_amplitude
            || config.triangle_frequency_hz > 1.0)
            throw std::invalid_argument("Invalid bounded motor-coordinate probe");
    }

    PairProbePlan(
        const PairProbeConfig& config, std::array<double, 2> initial, int inward_direction = 0)
        : config_(config)
        , inward_direction_(inward_direction) {
        validate_config(config);
        if (!std::isfinite(initial[0]) || !std::isfinite(initial[1]) || inward_direction < -1
            || inward_direction > 1)
            throw std::invalid_argument("Probe start requires finite motor positions");
        add(Kind::kHold, initial, initial, config.hold_s);
        // The physical inner-knee stop cannot track perfect common-mode motion
        // while the two real motors respond at different speeds. First create
        // opening room using the auxiliary drive alone, then keep that safer
        // interior pose as the return anchor; never return to the hard stop.
        const std::array anchor{initial[0], initial[1] + inward_direction * config.knee_amplitude};
        if (inward_direction != 0) {
            add(Kind::kMove, initial, anchor, config.move_s);
            add(Kind::kHold, anchor, anchor, config.hold_s);
        }
        const std::array common{
            anchor[0] + config.common_amplitude, anchor[1] + config.common_amplitude};
        const std::array common_minus{
            anchor[0] - config.common_amplitude, anchor[1] - config.common_amplitude};
        const double double_common = 2 * config.common_amplitude;
        const std::array common_double{anchor[0] + double_common, anchor[1] + double_common};
        const double first_direction = inward_direction ? inward_direction : 1;
        const double first_change = first_direction * config.knee_amplitude;
        const double second_change =
            (inward_direction ? inward_direction * .5 : -1) * config.knee_amplitude;
        const std::array knee_plus{anchor[0], anchor[1] + first_change};
        const std::array knee_minus{anchor[0], anchor[1] + second_change};
        for (const auto& target : {common, common_minus, common_double, knee_plus, knee_minus}) {
            add(Kind::kMove, anchor, target, config.move_s);
            add(Kind::kHold, target, target, config.hold_s);
            if (target == common || target == common_minus || target == common_double)
                add(Kind::kHold, target, target, config.gravity_hold_s);
            add(Kind::kMove, target, anchor, config.move_s);
            add(Kind::kHold, anchor, anchor, config.hold_s);
        }
        const std::array step_common{
            anchor[0] + config.step_amplitude, anchor[1] + config.step_amplitude};
        const std::array step_knee{anchor[0], anchor[1] + first_direction * config.step_amplitude};
        for (const auto& target : {step_common, step_knee}) {
            add(Kind::kStep, anchor, target, config.step_rise_s);
            add(Kind::kHold, target, target, config.gravity_hold_s);
            add(Kind::kStep, target, anchor, config.step_rise_s);
            add(Kind::kHold, anchor, anchor, config.hold_s);
        }
        add(Kind::kTriangleCommon, anchor, anchor, config.triangle_s);
        add(Kind::kHold, anchor, anchor, config.hold_s);
        add(Kind::kTriangleKnee, anchor, anchor, config.triangle_s);
        add(Kind::kHold, anchor, anchor, config.hold_s);
        add(Kind::kExcite, anchor, anchor, config.excite_s);
        add(Kind::kHold, anchor, anchor, config.hold_s);
        add(Kind::kMove, anchor, knee_plus, config.move_s);
        add(Kind::kHold, knee_plus, knee_plus, config.hold_s);
        add(Kind::kValidation, knee_plus, knee_plus, config.validation_s);
        add(Kind::kHold, knee_plus, knee_plus, config.hold_s);
        add(Kind::kMove, knee_plus, anchor, config.move_s);
        add(Kind::kHold, anchor, anchor, config.hold_s);
        if (duration_s_ > 120.0)
            throw std::invalid_argument("Probe exceeds 120 seconds");
    }

    [[nodiscard]] double duration() const { return duration_s_; }

    [[nodiscard]] PairSample at(double elapsed) const {
        if (!std::isfinite(elapsed) || elapsed < 0 || elapsed > duration_s_)
            throw std::out_of_range("Probe time outside trajectory");
        const Segment* segment = &segments_.back();
        for (const auto& candidate : segments_)
            if (elapsed < candidate.end_s) {
                segment = &candidate;
                break;
            }
        const double t =
            std::clamp(elapsed - (segment->end_s - segment->duration_s), 0.0, segment->duration_s);
        const double u = t / segment->duration_s;
        PairSample sample;
        sample.position = segment->from;
        sample.beta = std::numeric_limits<double>::quiet_NaN();
        sample.segment_id = segment->id;
        switch (segment->kind) {
        case Kind::kHold: sample.waveform = 0; break;
        case Kind::kMove: sample.waveform = 1; break;
        case Kind::kExcite: sample.waveform = 2; break;
        case Kind::kStep: sample.waveform = 3; break;
        case Kind::kTriangleCommon:
        case Kind::kTriangleKnee: sample.waveform = 4; break;
        case Kind::kValidation: sample.waveform = 5; break;
        }
        const bool common_triangle = segment->kind == Kind::kTriangleCommon;
        const bool knee_triangle = segment->kind == Kind::kTriangleKnee;
        const bool triangle = common_triangle || knee_triangle;
        if (segment->kind == Kind::kMove || segment->kind == Kind::kStep) {
            const double blend = u * u * u * (10.0 + u * (-15.0 + 6.0 * u));
            const double velocity = 30.0 * u * u * (1.0 - u) * (1.0 - u) / segment->duration_s;
            const double curvature = 1.0 - 3.0 * u + 2.0 * u * u;
            const double acceleration =
                60.0 * u * curvature / (segment->duration_s * segment->duration_s);
            for (std::size_t j = 0; j < 2; ++j) {
                const double change = segment->to[j] - segment->from[j];
                sample.position[j] += change * blend;
                sample.velocity[j] = change * velocity;
                sample.acceleration[j] = change * acceleration;
            }
        } else if (triangle) {
            const double x = std::numbers::pi * u;
            const double sn = std::sin(x), cs = std::cos(x);
            const double window = std::pow(sn, 4);
            const double window_rate = std::numbers::pi / segment->duration_s;
            const double dw = 4 * std::pow(sn, 3) * cs * window_rate;
            const double d2window = 12 * sn * sn * cs * cs - 4 * window;
            const double ddw = d2window * window_rate * window_rate;
            const double omega = 2 * std::numbers::pi * config_.triangle_frequency_hz;
            double wave = 0, wave_velocity = 0, wave_acceleration = 0;
            for (int n : {1, 3, 5}) {
                const double harmonic = n * omega;
                const double sign = n == 3 ? -1.0 : 1.0;
                const double pi_squared = std::numbers::pi * std::numbers::pi;
                const double coefficient = sign * 8.0 / (pi_squared * n * n);
                wave += coefficient * std::sin(harmonic * t);
                wave_velocity += coefficient * harmonic * std::cos(harmonic * t);
                wave_acceleration -= coefficient * harmonic * harmonic * std::sin(harmonic * t);
            }
            const bool knee_only = segment->kind == Kind::kTriangleKnee;
            const double direction = knee_only && inward_direction_ ? inward_direction_ * .5 : 1.0;
            const double amplitude = config_.triangle_amplitude * direction;
            const double bias = knee_only && inward_direction_ ? 1.0 : 0.0;
            const double position = amplitude * window * (wave + bias);
            const double velocity = amplitude * (dw * (wave + bias) + window * wave_velocity);
            const double envelope_second = ddw * (wave + bias);
            const double product_second = 2 * dw * wave_velocity + window * wave_acceleration;
            const double acceleration = amplitude * (envelope_second + product_second);
            for (std::size_t j = knee_only ? 1 : 0; j < 2; ++j) {
                sample.position[j] += position;
                sample.velocity[j] += velocity;
                sample.acceleration[j] += acceleration;
            }
        } else if (segment->kind == Kind::kExcite || segment->kind == Kind::kValidation) {
            sample.validation = segment->kind == Kind::kValidation;
            const double x = std::numbers::pi * u;
            const double sn = std::sin(x), cs = std::cos(x);
            const double window = std::pow(sn, 4);
            const double window_rate = std::numbers::pi / segment->duration_s;
            const double dw = 4 * std::pow(sn, 3) * cs * window_rate;
            const double d2window = 12 * sn * sn * cs * cs - 4 * window;
            const double ddw = d2window * window_rate * window_rate;
            const auto add_sine = [&](double amplitude, double frequency, double phase, double bias,
                                      std::size_t start) {
                const double omega = 2 * std::numbers::pi * frequency;
                const double sn_wave = std::sin(omega * t + phase);
                const double cs_wave = std::cos(omega * t + phase);
                const double position = amplitude * window * (sn_wave + bias);
                const double velocity =
                    amplitude * (dw * (sn_wave + bias) + window * omega * cs_wave);
                const double oscillation =
                    2 * dw * omega * cs_wave - window * omega * omega * sn_wave;
                const double wave_acceleration = ddw * (sn_wave + bias) + oscillation;
                const double acceleration = amplitude * wave_acceleration;
                for (std::size_t j = start; j < 2; ++j) {
                    sample.position[j] += position;
                    sample.velocity[j] += velocity;
                    sample.acceleration[j] += acceleration;
                }
            };
            auto frequencies = config_.frequencies_hz;
            if (sample.validation)
                frequencies = config_.validation_frequencies_hz;
            add_sine(config_.sine_common_amplitude, frequencies[0], 0.0, 0.0, 0);
            const double knee_scale = inward_direction_ ? inward_direction_ * .5 : 1.0;
            const double knee_amplitude = config_.sine_knee_amplitude * knee_scale;
            const double bias = inward_direction_ ? 1.0 : 0.0;
            add_sine(knee_amplitude, frequencies[1], std::numbers::pi / 2, bias, 1);
        }
        return sample;
    }

private:
    enum class Kind { kHold, kMove, kExcite, kStep, kTriangleCommon, kTriangleKnee, kValidation };
    struct Segment {
        Kind kind;
        std::array<double, 2> from, to;
        double duration_s, end_s;
        int id;
    };
    void add(Kind kind, std::array<double, 2> from, std::array<double, 2> to, double duration_s) {
        duration_s_ += duration_s;
        segments_.push_back(
            {kind, from, to, duration_s, duration_s_, static_cast<int>(segments_.size())});
    }

    const PairProbeConfig config_;
    int inward_direction_ = 0;
    std::vector<Segment> segments_;
    double duration_s_ = 0;
};

struct PairTrajectoryConfig {
    std::vector<double> pose_hip, pose_beta_degrees, frequencies_hz, hip_amplitudes,
        beta_amplitudes_degrees;
    double move_s = 0, hold_s = 0, excite_s = 0;
    double max_hip_excitation = 0, max_beta_excitation_degrees = 0;
};

class PairPlanner {
public:
    PairPlanner(
        const PairTrajectoryConfig& config, const KneeLut& lut, double beta_margin,
        double current_hip, double current_delta)
        : config_(config)
        , lut_(lut) {
        const auto finite_positive = [](double x) { return std::isfinite(x) && x > 0; };
        const double safe_min = std::max(KneeLut::kBetaMin, lut.beta_min()) + beta_margin;
        const double safe_max = std::min(KneeLut::kBetaMax, lut.beta_max()) - beta_margin;
        if (!std::isfinite(beta_margin) || beta_margin <= 0 || safe_min >= safe_max)
            throw std::invalid_argument("Measured knee LUT has no safe interior after margin");
        if (config.pose_hip.size() < 3 || config.pose_hip.size() != config.pose_beta_degrees.size()
            || config.frequencies_hz.size() < 2
            || config.frequencies_hz.size() != config.hip_amplitudes.size()
            || config.frequencies_hz.size() != config.beta_amplitudes_degrees.size()
            || !finite_positive(config.move_s) || !finite_positive(config.hold_s)
            || !finite_positive(config.excite_s) || !finite_positive(config.max_hip_excitation)
            || !finite_positive(config.max_beta_excitation_degrees))
            throw std::invalid_argument("Incomplete measured identification trajectory");
        poses_.reserve(config.pose_hip.size());
        segments_.reserve(4 * config.pose_hip.size() + 12);
        for (std::size_t i = 0; i < config.pose_hip.size(); ++i) {
            const double beta = config.pose_beta_degrees[i] * std::numbers::pi / 180.0;
            if (!std::isfinite(config.pose_hip[i]) || !std::isfinite(beta) || beta <= safe_min
                || beta >= safe_max)
                throw std::invalid_argument("Pose outside measured knee interior");
            poses_.push_back({config.pose_hip[i], beta});
        }
        if (std::abs(poses_[0].second - poses_[1].second) > 1e-8
            || std::abs(poses_[0].first - poses_[2].first) > 1e-8
            || std::abs(poses_[0].first - poses_[1].first) < 1e-5
            || std::abs(poses_[0].second - poses_[2].second) < 1e-5)
            throw std::invalid_argument(
                "First poses must define common rotation and flexion/reversals");
        double sum_hip = 0, sum_beta = 0;
        for (std::size_t i = 0; i < config.frequencies_hz.size(); ++i) {
            const double hz = config.frequencies_hz[i];
            if (!finite_positive(hz) || hz > 10.0 || !std::isfinite(config.hip_amplitudes[i])
                || !std::isfinite(config.beta_amplitudes_degrees[i]))
                throw std::invalid_argument("Invalid multisine frequency or amplitude");
            for (std::size_t j = 0; j < i; ++j)
                if (std::abs(hz - config.frequencies_hz[j]) < 1e-5)
                    throw std::invalid_argument("Multisine frequencies must be distinct");
            sum_hip += std::abs(config.hip_amplitudes[i]);
            sum_beta += std::abs(config.beta_amplitudes_degrees[i]);
        }
        if (sum_hip <= 0 || sum_beta <= 0 || sum_hip > config.max_hip_excitation
            || sum_beta > config.max_beta_excitation_degrees)
            throw std::invalid_argument("Both coupled motors need bounded, nonzero excitation");
        const Pose initial{current_hip, lut.beta_from_delta(current_delta)};
        if (!std::isfinite(current_hip) || initial.second <= safe_min || initial.second >= safe_max)
            throw std::invalid_argument("Current pose lacks measured knee interior margin");
        Pose cursor = initial;
        const auto move = [&](Pose target) {
            add(Segment::kMove, cursor, target, config.move_s);
            cursor = target;
        };
        const auto hold = [&] { add(Segment::kHold, cursor, cursor, config.hold_s); };
        move(poses_[0]);
        hold();
        move(poses_[1]);
        hold();
        move(poses_[0]);
        hold();
        move(poses_[2]);
        hold();
        move(poses_[0]);
        hold();
        for (const auto& pose : poses_) {
            move(pose);
            hold();
            add(Segment::kSine, pose, pose, config.excite_s);
            hold();
        }
        move(poses_[0]);
        hold();
        if (total_s_ > 180.0)
            throw std::invalid_argument("Identification path exceeds 180 seconds");
    }

    [[nodiscard]] double duration() const { return total_s_; }

    [[nodiscard]] PairSample at(double elapsed) const {
        if (!std::isfinite(elapsed) || elapsed < 0 || elapsed > total_s_)
            throw std::out_of_range("Trajectory time out of bounds");
        const Segment* segment = &segments_.back();
        for (const auto& candidate : segments_)
            if (elapsed < candidate.end_s) {
                segment = &candidate;
                break;
            }
        const double t =
            std::clamp(elapsed - (segment->end_s - segment->duration), 0.0, segment->duration);
        const double u = t / segment->duration;
        double hip = segment->from.first, beta = segment->from.second;
        double dhip = 0, dbeta = 0, ddhip = 0, ddbeta = 0;
        if (segment->kind == Segment::kMove) {
            const double blend = 10 * std::pow(u, 3) - 15 * std::pow(u, 4) + 6 * std::pow(u, 5);
            const double speed =
                (30 * u * u - 60 * std::pow(u, 3) + 30 * std::pow(u, 4)) / segment->duration;
            const double accel = (60 * u - 180 * u * u + 120 * std::pow(u, 3))
                               / (segment->duration * segment->duration);
            hip += (segment->to.first - hip) * blend;
            beta += (segment->to.second - beta) * blend;
            dhip = (segment->to.first - segment->from.first) * speed;
            dbeta = (segment->to.second - segment->from.second) * speed;
            ddhip = (segment->to.first - segment->from.first) * accel;
            ddbeta = (segment->to.second - segment->from.second) * accel;
        } else if (segment->kind == Segment::kSine) {
            const double angle = std::numbers::pi * u;
            const double sn = std::sin(angle), cs = std::cos(angle);
            const double w = std::pow(sn, 4);
            const double dw = 4 * std::pow(sn, 3) * cs * std::numbers::pi / segment->duration;
            const double ddw = (12 * sn * sn * cs * cs - 4 * std::pow(sn, 4))
                             * std::pow(std::numbers::pi / segment->duration, 2);
            for (std::size_t i = 0; i < config_.frequencies_hz.size(); ++i) {
                const double omega = 2 * std::numbers::pi * config_.frequencies_hz[i];
                const auto add_sine = [&](double amplitude, double phase, double& p, double& v,
                                          double& a) {
                    const double s = std::sin(omega * t + phase), c = std::cos(omega * t + phase);
                    p += amplitude * w * s;
                    v += amplitude * (dw * s + w * omega * c);
                    a += amplitude * (ddw * s + 2 * dw * omega * c - w * omega * omega * s);
                };
                add_sine(config_.hip_amplitudes[i], 0.0, hip, dhip, ddhip);
                add_sine(
                    config_.beta_amplitudes_degrees[i] * std::numbers::pi / 180.0,
                    std::numbers::pi / 2, beta, dbeta, ddbeta);
            }
        }
        const auto knee = lut_.at(beta);
        return {
            {hip, hip + knee.delta},
            {dhip, dhip + knee.slope * dbeta},
            {ddhip, ddhip + knee.slope * ddbeta + knee.curvature * dbeta * dbeta},
            beta,
            segment->id};
    }

private:
    using Pose = std::pair<double, double>; // hip, true beta (radians)
    struct Segment {
        enum Kind { kMove, kHold, kSine } kind;
        Pose from, to;
        double duration, end_s;
        int id;
    };

    void add(Segment::Kind kind, Pose from, Pose to, double duration) {
        total_s_ += duration;
        segments_.push_back(
            {kind, from, to, duration, total_s_, static_cast<int>(segments_.size())});
    }

    const PairTrajectoryConfig& config_;
    const KneeLut& lut_;
    std::vector<Pose> poses_;
    std::vector<Segment> segments_;
    double total_s_ = 0;
};

struct CascadeResult {
    double position_error, velocity_target, speed_error, preclip, integral_torque, torque;
};

// Same PC position PD as the RL path. The desired velocity is zero; the
// trajectory derivative is telemetry only, never a feedforward torque term.
inline CascadeResult pd_step(double q_ref, double q, double dq, double kp, double kd,
                             double max_torque) {
    const double error = q_ref - q;
    const double requested = kp * error - kd * dq;
    return {error, 0.0, -dq, requested, 0.0,
            std::clamp(requested, -max_torque, max_torque)};
}

inline CascadeResult cascade_step(
    double q_ref, double dq_ref, double q, double dq, double kp_position, double kp_velocity,
    double ki_velocity, double max_speed, double max_torque, double integral_limit, double dt,
    double& integral) {
    const double ep = q_ref - q;
    const double goal = std::clamp(dq_ref + kp_position * ep, -max_speed, max_speed);
    const double ev = goal - dq;
    const double candidate = std::clamp(integral + ev * dt, -integral_limit, integral_limit);
    const double requested = kp_velocity * ev + ki_velocity * candidate;
    // Conditional integration: a saturated actuator may unwind but never wind further up.
    if (ki_velocity > 0
        && (std::abs(requested) <= max_torque || (requested > max_torque && ev < 0)
            || (requested < -max_torque && ev > 0)))
        integral = candidate;
    const double preclip = kp_velocity * ev + ki_velocity * integral;
    return {ep,
            goal,
            ev,
            preclip,
            ki_velocity * integral,
            std::clamp(preclip, -max_torque, max_torque)};
}

inline std::array<double, 6> selected_torque_api(
    std::size_t side, const PairLimits& limits, const std::array<double, 2>& torque_model) {
    std::array<double, 6> command{};
    if (side < 2)
        for (std::size_t j = 0; j < 2; ++j)
            command[2 * side + j] = limits.sign[2 * side + j] * torque_model[j];
    return command;
}

} // namespace rmcs_core::controller::identification
