#pragma once

#include "identification/wheel_leg_pair_identification_planner.hpp"

namespace rmcs_core::controller::identification {

struct PairSweepConfig {
    double common_amplitude = 0, relative_amplitude = 0;
    double common_step = 0, relative_step = 0, step_rise_s = 0;
    double move_s = 0, quarter_turn_s = 0, dwell_s = 0;
    double chirp_s = 0, validation_s = 0, ramp_s = 0, relative_margin = 0;
    std::array<double, 2> common_hz{}, relative_hz{};
};

// A fixed-chassis, mounted-pair experiment. Common rotation preserves q_aux-q_hip;
// relative excitation changes the linkage shape. Neither coordinate is knee beta.
class PairSweepPlan {
public:
    static void validate_config(const PairSweepConfig& c) {
        for (double value : {c.common_amplitude, c.relative_amplitude, c.common_step,
                             c.relative_step, c.step_rise_s, c.move_s, c.quarter_turn_s,
                             c.dwell_s, c.chirp_s, c.validation_s, c.ramp_s, c.relative_margin})
            if (!std::isfinite(value) || value <= 0)
                throw std::invalid_argument("Sweep parameters must be positive and finite");
        for (const auto& band : {c.common_hz, c.relative_hz})
            if (!std::isfinite(band[0]) || !std::isfinite(band[1])
                || !(0 < band[0] && band[0] < band[1]))
                throw std::invalid_argument("Sweep frequency bands must be positive and ordered");
        if (2 * c.ramp_s >= std::min(c.chirp_s, c.validation_s)
            || c.relative_step > c.relative_amplitude || c.common_step > c.common_amplitude)
            throw std::invalid_argument("Sweep ramp/step does not fit its excitation envelope");
    }

    PairSweepPlan(
        const PairSweepConfig& config, const std::array<double, 2>& initial,
        double delta_low, double delta_high)
        : config_(config) {
        validate_config(config);
        const double delta = initial[1] - initial[0];
        // Room for a second shape and its relative chirp, in either direction.
        const double room = 2 * config.relative_amplitude + config.relative_margin;
        if (!std::isfinite(initial[0]) || !std::isfinite(initial[1])
            || !std::isfinite(delta_low) || !std::isfinite(delta_high)
            || delta <= delta_low || delta >= delta_high || delta_low + room >= delta_high - room)
            throw std::invalid_argument("Sweep needs a valid pair branch with room for two shapes");
        const double anchor_delta = std::clamp(delta, delta_low + room, delta_high - room);
        const std::array anchor{initial[0], initial[0] + anchor_delta};
        const double direction = anchor_delta <= (delta_low + delta_high) / 2 ? 1 : -1;
        const std::array second{anchor[0], anchor[1] + direction * config.relative_amplitude};
        add(Kind::kHold, initial, initial, config.dwell_s);
        add(Kind::kMove, initial, anchor, config.move_s);
        add(Kind::kHold, anchor, anchor, config.dwell_s);

        // Both signs distinguish load bias from directional friction. Steps
        // have a finite quintic rise, not a discontinuous position command.
        for (bool relative : {false, true})
            for (double sign : {1.0, -1.0}) {
                auto target = anchor;
                for (std::size_t j = relative ? 1 : 0; j < 2; ++j)
                    target[j] += sign * (relative ? config.relative_step : config.common_step);
                add(Kind::kStep, anchor, target, config.step_rise_s);
                add(Kind::kHold, target, target, config.dwell_s);
                add(Kind::kStep, target, anchor, config.step_rise_s);
                add(Kind::kHold, anchor, anchor, config.dwell_s);
            }

        // One revolution and its reverse, with 90-degree dwells. Repeating at
        // a second shape samples gravity versus orientation and spring load
        // versus relative angle. References remain unwrapped throughout.
        gravity_grid(anchor);
        add(Kind::kCommonChirp, anchor, anchor, config.chirp_s);
        add(Kind::kHold, anchor, anchor, config.dwell_s);
        add(Kind::kRelativeChirp, anchor, anchor, config.chirp_s);
        add(Kind::kHold, anchor, anchor, config.dwell_s);
        add(Kind::kMove, anchor, second, config.move_s);
        add(Kind::kHold, second, second, config.dwell_s);
        gravity_grid(second);
        add(Kind::kValidation, second, second, config.validation_s);
        add(Kind::kHold, second, second, config.dwell_s, true);
        add(Kind::kMove, second, anchor, config.move_s);
        add(Kind::kHold, anchor, anchor, config.dwell_s);
    }

    [[nodiscard]] double duration() const { return duration_s_; }

    [[nodiscard]] PairSample at(double elapsed) const {
        if (!std::isfinite(elapsed) || elapsed < 0 || elapsed > duration_s_)
            throw std::out_of_range("Sweep time outside trajectory");
        const Segment* segment = &segments_.back();
        for (const auto& candidate : segments_)
            if (elapsed < candidate.end_s) {
                segment = &candidate;
                break;
            }
        const double t = std::clamp(
            elapsed - (segment->end_s - segment->duration_s), 0.0, segment->duration_s);
        PairSample result;
        result.position = segment->from;
        result.beta = std::numeric_limits<double>::quiet_NaN();
        result.segment_id = segment->id;
        result.validation = segment->validation;
        if (segment->kind == Kind::kHold)
            return result;
        if (segment->kind == Kind::kMove || segment->kind == Kind::kStep
            || segment->kind == Kind::kRotation) {
            result.waveform = segment->kind == Kind::kStep ? 3
                            : segment->kind == Kind::kRotation ? 7 : 1;
            const auto blend = quintic(t / segment->duration_s, segment->duration_s);
            for (std::size_t j = 0; j < 2; ++j) {
                const double delta = segment->to[j] - segment->from[j];
                result.position[j] += delta * blend[0];
                result.velocity[j] = delta * blend[1];
                result.acceleration[j] = delta * blend[2];
            }
            return result;
        }
        result.waveform = 6; // Chirp; segment_role independently labels holdout data.
        const bool validation = segment->kind == Kind::kValidation;
        if (segment->kind == Kind::kCommonChirp || validation)
            add_chirp(result, t, segment->duration_s, config_.common_hz,
                      config_.common_amplitude * (validation ? .75 : 1), 0, validation, 0);
        if (segment->kind == Kind::kRelativeChirp || validation)
            add_chirp(result, t, segment->duration_s, config_.relative_hz,
                      config_.relative_amplitude * (validation ? .75 : 1), 1, validation,
                      validation ? std::numbers::pi / 2 : 0);
        return result;
    }

private:
    enum class Kind { kHold, kMove, kStep, kRotation, kCommonChirp, kRelativeChirp, kValidation };
    struct Segment {
        Kind kind;
        std::array<double, 2> from, to;
        double duration_s, end_s;
        int id;
        bool validation;
    };

    static std::array<double, 3> quintic(double u, double duration) {
        return {u * u * u * (10 + u * (-15 + 6 * u)),
                30 * u * u * (1 - u) * (1 - u) / duration,
                60 * u * (1 - 3 * u + 2 * u * u) / (duration * duration)};
    }

    void add_chirp(
        PairSample& sample, double t, double duration, std::array<double, 2> hz,
        double amplitude, std::size_t first_axis, bool reverse, double phase_offset) const {
        if (reverse)
            std::swap(hz[0], hz[1]);
        const double rate = (hz[1] - hz[0]) / duration;
        const double phase = 2 * std::numbers::pi * (hz[0] * t + .5 * rate * t * t) + phase_offset;
        const double omega = 2 * std::numbers::pi * (hz[0] + rate * t);
        const double alpha = 2 * std::numbers::pi * rate;
        std::array<double, 3> window{1, 0, 0};
        if (t < config_.ramp_s)
            window = quintic(t / config_.ramp_s, config_.ramp_s);
        else if (t > duration - config_.ramp_s) {
            window = quintic((duration - t) / config_.ramp_s, config_.ramp_s);
            window[1] = -window[1];
        }
        const double sn = std::sin(phase), cs = std::cos(phase);
        const double q = amplitude * window[0] * sn;
        const double dq = amplitude * (window[1] * sn + window[0] * omega * cs);
        const double ddq = amplitude * (window[2] * sn + 2 * window[1] * omega * cs
                                        + window[0] * (alpha * cs - omega * omega * sn));
        for (std::size_t j = first_axis; j < 2; ++j) {
            sample.position[j] += q;
            sample.velocity[j] += dq;
            sample.acceleration[j] += ddq;
        }
    }

    void gravity_grid(const std::array<double, 2>& anchor) {
        auto previous = anchor;
        for (int quarter : {1, 2, 3, 4, 3, 2, 1, 0}) {
            const double angle = quarter * std::numbers::pi / 2;
            const std::array target{anchor[0] + angle, anchor[1] + angle};
            add(Kind::kRotation, previous, target, config_.quarter_turn_s);
            add(Kind::kHold, target, target, config_.dwell_s);
            previous = target;
        }
    }

    void add(Kind kind, std::array<double, 2> from, std::array<double, 2> to,
             double duration, bool validation = false) {
        duration_s_ += duration;
        segments_.push_back({kind, from, to, duration, duration_s_,
                             static_cast<int>(segments_.size()), validation || kind == Kind::kValidation});
    }

    PairSweepConfig config_;
    std::vector<Segment> segments_;
    double duration_s_ = 0;
};

} // namespace rmcs_core::controller::identification
