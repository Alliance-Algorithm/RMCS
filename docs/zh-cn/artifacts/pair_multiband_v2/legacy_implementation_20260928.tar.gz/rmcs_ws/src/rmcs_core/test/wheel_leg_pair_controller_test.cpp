#include <array>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <typeinfo>
#include <vector>

#include <gtest/gtest.h>
#include <rclcpp/rclcpp.hpp>
#include <rmcs_executor/component.hpp>

// This test executable does not link or start the production Executor. Use its
// existing friendship only to bind the real Component registrations, including
// their type checks and bind callbacks; never expose controller private state.
namespace rmcs_executor {
class Executor {
public:
    template <typename T>
    static void bind(Component& component, const std::string& name, T& value) {
        for (auto& port : component.input_list_) {
            if (port.name != name)
                continue;
            if (port.type != typeid(T) || port.kind != InterfaceKind::Normal)
                throw std::runtime_error("Wrong input type: " + name);
            port.bind(port.binding, &value);
            return;
        }
        throw std::runtime_error("Input is not registered: " + name);
    }

    template <typename T>
    static const T& output(Component& component, const std::string& name) {
        for (auto& port : component.output_list_) {
            if (port.name != name)
                continue;
            if (port.type != typeid(T) || port.kind != InterfaceKind::Normal)
                throw std::runtime_error("Wrong output type: " + name);
            return *static_cast<const T*>(port.binding);
        }
        throw std::runtime_error("Output is not registered: " + name);
    }

    static void require_bound_inputs(Component& component) {
        for (auto& port : component.input_list_) {
            void* destination = nullptr;
            std::memcpy(&destination, port.binding, sizeof(destination));
            if (!destination)
                throw std::runtime_error("Unbound controller input: " + port.name);
        }
    }
};
} // namespace rmcs_executor

// Compile the actual controller update(), parameter validation, planner and
// cascade into this offline test. No hardware class is included or constructed.
#include "identification/wheel_leg_pair_identification_controller.cpp"

namespace rmcs_core::controller::identification {
namespace {

class PairControllerTest : public ::testing::Test {
protected:
    using Clock = std::chrono::steady_clock;
    using Switch = rmcs_msgs::Switch;
    using Ports = rmcs_executor::Executor;
    static constexpr std::array kAxes{"left_hip_joint", "left_knee_joint", "right_hip_joint",
                                      "right_knee_joint", "left_wheel", "right_wheel"};

    virtual std::string stage() const { return "hold"; }
    virtual std::string pattern() const { return "bounded"; }
    virtual const char* profile_path() const { return PAIR_CONTROLLER_TEST_PROFILE; }
    virtual std::string delta_policy_override() const { return {}; }
    virtual std::vector<std::string> extra_parameters() const { return {}; }

    void SetUp() override {
        // These are synthetic valid bench coordinates, not a real robot LUT.
        // Load the real profile and override only the test setup through ROS's
        // public parameter mechanism, as an operator-supplied YAML would do.
        std::vector<std::string> args{
            "wheel_leg_pair_controller_test", "--ros-args", "--params-file",
            profile_path(), "--log-level", "error"};
        for (const auto& parameter : std::vector<std::string>{
                 "side:=left", "probe_pattern:=" + pattern(), "experiment_stage:=" + stage(), "hold_test_duration_s:=0.2",
                 "phase_api_angle:=" + std::string(pattern() != "bounded" ? "true" : "false"), "model_sign:=[1.0,1.0,1.0,1.0]",
                 "model_offset:=[0.0,0.0,0.0,0.0]", "spring_delta_min:=[0.44,0.44]",
                 "spring_delta_max:=[1.32,1.32]", "beta_margin_degrees:=1.0",
                 "left_beta_degrees:=[40.0,60.0,85.0,105.0]",
                 "right_beta_degrees:=[40.0,60.0,85.0,105.0]",
                 "left_delta_rad:=[0.46,0.7,1.0,1.3]",
                 "right_delta_rad:=[0.46,0.7,1.0,1.3]",
                 "gravity_feedforward_model:=[0.0,0.0,0.0,0.0]",
                 "ki_velocity:=[0.5,0.5,0.5,0.5]",
                 "integral_limit:=[0.2,0.2,0.2,0.2]", "sweep_relative_amplitude:=0.15", "ready_timeout_s:=" + std::string(pattern() == "multiband_chirp" ? "12.0" : "3.0")}) {
            args.push_back("-p");
            args.push_back(parameter);
        }
        if (!delta_policy_override().empty()) {
            args.push_back("-p");
            args.push_back("probe_measured_delta_policy:=" + delta_policy_override());
        }
        for (const auto& parameter : extra_parameters()) {
            args.push_back("-p");
            args.push_back(parameter);
        }
        std::vector<const char*> argv;
        for (const auto& arg : args)
            argv.push_back(arg.c_str());
        rclcpp::init(static_cast<int>(argv.size()), argv.data());
        rmcs_executor::Component::initializing_component_name =
            "wheel_leg_pair_identification_controller";
        controller_ = std::make_unique<WheelLegPairIdentificationController>();
        bind("/predefined/update_count", tick_);
        bind("/predefined/update_rate", rate_);
        bind("/predefined/timestamp", time_);
        bind("/remote/switch/left", left_);
        bind("/remote/switch/right", right_);
        bind("/wheel_leg/feedback_fresh", feedback_fresh_);
        bind("/wheel_leg/imu/last_steady_ns", imu_ns_);
        bind("/wheel_leg/dr16_fresh", remote_fresh_);
        bind("/wheel_leg/dm_control_ready", ready_);
        max_torque_.fill(20.0);
        for (std::size_t i = 0; i < kAxes.size(); ++i) {
            const auto prefix = std::string{"/wheel_leg/"} + kAxes[i];
            bind(prefix + "/angle", angle_[i]);
            bind(prefix + "/velocity", velocity_[i]);
            bind(prefix + "/max_torque", max_torque_[i]);
            bind(prefix + "/feedback_steady_ns", feedback_ns_[i]);
            if (i < 4) {
                bind(prefix + "/fault_code", fault_[i]);
                bind(prefix + "/status_code", status_[i]);
            }
        }
        Ports::require_bound_inputs(*controller_);
        ASSERT_EQ(phase(), 0);
        EXPECT_FALSE(enabled());
        EXPECT_FALSE(clearing());
        for (const auto* axis : kAxes)
            EXPECT_TRUE(std::isnan(output<double>(std::string{axis} + "/control_torque")));
    }

    void TearDown() override {
        controller_.reset();
        rclcpp::shutdown();
    }

    template <typename T>
    void bind(const std::string& name, T& value) { Ports::bind(*controller_, name, value); }

    template <typename T>
    const T& output(const std::string& name) {
        return Ports::output<T>(*controller_, "/wheel_leg/" + name);
    }

    int phase() { return output<int>("identification/phase"); }
    int failure() { return output<int>("identification/failure_reason"); }
    bool enabled() { return output<bool>("enable_request"); }
    bool clearing() { return output<bool>("clear_error_request"); }

    void step(bool fresh_feedback = true, std::size_t tick_increment = 1, int elapsed_ms = 1) {
        tick_ += tick_increment;
        time_ += std::chrono::milliseconds{elapsed_ms};
        if (fresh_feedback) {
            const auto now = Clock::now().time_since_epoch();
            const auto ns = std::chrono::duration_cast<std::chrono::nanoseconds>(now).count();
            feedback_ns_.fill(static_cast<std::uint64_t>(ns));
            imu_ns_ = static_cast<std::uint64_t>(ns);
            feedback_fresh_ = true;
        }
        controller_->update();
        for (const auto* axis : kAxes) {
            const auto torque = output<double>(std::string{axis} + "/control_torque");
            if (phase() == 2) {
                EXPECT_TRUE(std::isfinite(torque));
                EXPECT_LE(std::abs(torque), 20.0);
            } else {
                // NaN releases the controller port. The hardware layer owns
                // conversion to neutral motor frames; this test has no device.
                EXPECT_TRUE(std::isnan(torque)) << axis << ": phase=" << phase();
            }
        }
    }

    void start_running() {
        step();
        ASSERT_EQ(phase(), 1) << failure();
        ASSERT_TRUE(enabled());
        status_[0] = status_[1] = 1;
        ready_ = true;
        step();
        ASSERT_EQ(phase(), 2) << failure();
    }

    void expect_down_reset() {
        EXPECT_EQ(phase(), 0);
        EXPECT_EQ(failure(), 0);
        EXPECT_FALSE(enabled());
        EXPECT_FALSE(clearing());
        EXPECT_EQ(output<int>("identification/segment_id"), -1);
        for (const auto* axis : kAxes)
            EXPECT_TRUE(std::isnan(output<double>(std::string{axis} + "/control_torque")))
                << axis;
        EXPECT_TRUE(output<Eigen::Vector4d>("identification/torque_integral_model").isZero());
        EXPECT_TRUE(output<Eigen::Vector4d>("identification/velocity_target_model").isZero());
    }

    std::unique_ptr<WheelLegPairIdentificationController> controller_;
    std::size_t tick_ = 0;
    double rate_ = 1000.0;
    Clock::time_point time_ = Clock::now();
    Switch left_ = Switch::MIDDLE, right_ = Switch::MIDDLE;
    bool feedback_fresh_ = true, remote_fresh_ = true, ready_ = false;
    std::uint64_t imu_ns_ = 0;
    std::array<double, 6> angle_{0.0, 1.0, 0.0, 1.0, 0.0, 0.0};
    std::array<double, 6> velocity_{}, max_torque_{};
    std::array<std::uint64_t, 6> feedback_ns_{};
    std::array<int, 4> fault_{}, status_{};
};

TEST_F(PairControllerTest, FirstFreshMiddleRequestsEnableWithoutPriorDownDwell) {
    step();
    EXPECT_EQ(phase(), 1) << failure();
    EXPECT_TRUE(enabled());
    EXPECT_TRUE(clearing());
}

TEST_F(PairControllerTest, FirstMiddleWaitsForInitialFeedbackBeforeRequestingEnable) {
    feedback_fresh_ = false;
    angle_[0] = std::numeric_limits<double>::quiet_NaN();
    for (int i = 0; i < 2500; ++i) {
        step(false);
        ASSERT_EQ(phase(), 1) << "tick=" << i << " reason=" << failure();
        ASSERT_FALSE(enabled());
        ASSERT_FALSE(clearing());
    }
    angle_[0] = 0.0;
    step();
    EXPECT_EQ(phase(), 1) << failure();
    EXPECT_TRUE(enabled());
    EXPECT_TRUE(clearing());
}

TEST_F(PairControllerTest, MissingInitialFeedbackTimesOutAndMiddleDoesNotRetry) {
    feedback_fresh_ = false;
    for (int i = 0; i < 3010; ++i)
        step(false);
    ASSERT_EQ(phase(), -1);
    EXPECT_FALSE(enabled());
    EXPECT_FALSE(clearing());
    const int latched_reason = failure();
    step();
    EXPECT_EQ(phase(), -1);
    EXPECT_EQ(failure(), latched_reason);
    EXPECT_FALSE(enabled());
}

TEST_F(PairControllerTest, FeedbackLossAfterEnableRequestLatchesInsteadOfWaitingAgain) {
    step();
    ASSERT_EQ(phase(), 1);
    ASSERT_TRUE(enabled());
    feedback_fresh_ = false;
    feedback_ns_.fill(0);
    step(false);
    ASSERT_EQ(phase(), -1);
    EXPECT_FALSE(enabled());
    EXPECT_FALSE(clearing());
    step();
    EXPECT_EQ(phase(), -1);
    EXPECT_FALSE(enabled());
    left_ = right_ = Switch::DOWN;
    step(false);
    expect_down_reset();
    left_ = right_ = Switch::MIDDLE;
    feedback_fresh_ = false;
    feedback_ns_.fill(0);
    step(false);
    EXPECT_EQ(phase(), 1);
    EXPECT_FALSE(enabled());
    EXPECT_FALSE(clearing());
}

TEST_F(PairControllerTest, FeedbackChangesUpdateTorqueEveryMillisecondNotEveryFifthTick) {
    start_running();
    ASSERT_EQ(phase(), 2);
    angle_[0] -= .01;
    double integral = 0;
    for (int i = 0; i < 10; ++i) {
        velocity_[0] = i % 2 ? -.1 : .1;
        step();
        ASSERT_EQ(phase(), 2) << failure();
        const double speed_error = .06 - velocity_[0];
        integral += speed_error * .001;
        EXPECT_NEAR(output<Eigen::Vector4d>("identification/speed_error_model")[0], speed_error, 1e-12);
        EXPECT_NEAR(output<double>("left_hip_joint/control_torque"),
                    10 * speed_error + .5 * integral, 1e-10);
        EXPECT_DOUBLE_EQ(output<double>("right_hip_joint/control_torque"), 0);
        EXPECT_DOUBLE_EQ(output<double>("right_knee_joint/control_torque"), 0);
    }
}

TEST_F(PairControllerTest, AccelerationSpikeIsDiagnosticAndDownStillReleasesAllAxes) {
    start_running();
    ASSERT_EQ(phase(), 2);
    // A 0.2 rad/s velocity step over the next 1 ms control interval exceeds
    // the old 30 rad/s^2 stop threshold, but remains within tracking limits.
    velocity_[0] = 0.2;
    for (int i = 0; i < 8; ++i)
        step();
    EXPECT_EQ(phase(), 2);
    EXPECT_EQ(failure(), 0);
    EXPECT_TRUE(enabled());
    EXPECT_GT(std::abs(output<double>("left_hip_joint/control_torque")), 0.0);
    EXPECT_LE(std::abs(output<double>("left_hip_joint/control_torque")), 20.0);

    left_ = right_ = Switch::DOWN;
    feedback_fresh_ = false;
    feedback_ns_.fill(0);
    step(false);
    expect_down_reset();
}

TEST_F(PairControllerTest, RunningFeedbackLossReleasesAllAxesAndLatches) {
    start_running();
    ASSERT_EQ(phase(), 2);
    angle_[0] -= 0.01;
    angle_[1] -= 0.01;
    for (int i = 0; i < 8; ++i)
        step();
    ASSERT_EQ(phase(), 2) << failure();
    ASSERT_GT(std::abs(output<double>("left_hip_joint/control_torque")), 0.0);
    feedback_fresh_ = false;
    feedback_ns_[0] = 0;
    step(false);
    ASSERT_EQ(phase(), -1);
    EXPECT_EQ(failure(), 40);
    EXPECT_FALSE(enabled());
    EXPECT_FALSE(clearing());
    EXPECT_TRUE(output<Eigen::Vector4d>("identification/torque_integral_model").isZero());
    step();
    EXPECT_EQ(phase(), -1);
    EXPECT_FALSE(enabled());
    left_ = right_ = Switch::DOWN;
    feedback_ns_.fill(0);
    feedback_fresh_ = false;
    step(false);
    expect_down_reset();
}

TEST_F(PairControllerTest, FreshDownOverridesTickSkipStaleFeedbackAndResetsCascadeForRearm) {
    start_running();
    ASSERT_EQ(phase(), 2);
    angle_[0] -= 0.01;
    angle_[1] -= 0.01;
    for (int i = 0; i < 8; ++i)
        step();
    ASSERT_EQ(phase(), 2) << failure();
    ASSERT_GT(output<Eigen::Vector4d>("identification/torque_integral_model").norm(), 0.0);
    ASSERT_GT(std::abs(output<double>("left_hip_joint/control_torque")), 0.0);

    step(true, 7);
    ASSERT_EQ(phase(), -1);
    ASSERT_EQ(failure(), 2);
    step();
    EXPECT_EQ(phase(), -1);
    EXPECT_FALSE(enabled());

    left_ = right_ = Switch::DOWN;
    feedback_fresh_ = false;
    feedback_ns_.fill(0);
    rate_ = std::numeric_limits<double>::quiet_NaN();
    step(false, 19, -100);
    expect_down_reset();

    // An arbitrary new clock/tick origin is valid after reset. The next hold
    // must capture this new pose, without the previous plan or integrator.
    rate_ = 1000.0;
    left_ = right_ = Switch::MIDDLE;
    ready_ = false;
    status_[0] = status_[1] = 0;
    angle_[0] = 0.1;
    angle_[1] = 1.1;
    step(true, 31, -100);
    ASSERT_EQ(phase(), 1) << failure();
    EXPECT_TRUE(enabled());
    ready_ = true;
    status_[0] = status_[1] = 1;
    step();
    ASSERT_EQ(phase(), 2) << failure();
    EXPECT_NEAR(output<Eigen::Vector4d>("identification/reference_model")[0], 0.1, 1e-12);
    EXPECT_DOUBLE_EQ(output<double>("left_hip_joint/control_torque"), 0.0);
    EXPECT_TRUE(output<Eigen::Vector4d>("identification/torque_integral_model").isZero());
}

TEST_F(PairControllerTest, SelectedFaultEightLatchesUntilDownThenCanRequestClear) {
    start_running();
    ASSERT_EQ(phase(), 2);
    status_[0] = status_[1] = 8;
    fault_[0] = fault_[1] = 8;
    ready_ = false;
    step();
    ASSERT_EQ(phase(), -1);
    EXPECT_FALSE(clearing());
    step();
    EXPECT_EQ(phase(), -1);
    EXPECT_FALSE(enabled());
    left_ = right_ = Switch::DOWN;
    step();
    expect_down_reset();
    left_ = right_ = Switch::MIDDLE;
    step();
    ASSERT_EQ(phase(), 1) << failure();
    EXPECT_TRUE(enabled());
    EXPECT_TRUE(clearing());
    fault_[0] = fault_[1] = 0;
    status_[0] = status_[1] = 1;
    ready_ = true;
    step();
    EXPECT_EQ(phase(), 2) << failure();
}

TEST_F(PairControllerTest, ParkedFaultAndEnabledParkedDriveBothBlockArming) {
    status_[2] = fault_[2] = 8;
    step();
    ASSERT_EQ(phase(), -1);
    EXPECT_FALSE(enabled());
    EXPECT_FALSE(clearing());
    left_ = right_ = Switch::DOWN;
    step();
    expect_down_reset();
    fault_[2] = 0;
    status_[2] = 1;
    left_ = right_ = Switch::MIDDLE;
    step();
    EXPECT_EQ(phase(), -1);
    EXPECT_FALSE(enabled());
    EXPECT_FALSE(clearing());
}

TEST_F(PairControllerTest, CompletedRunRequiresDownResetBeforeAnotherMiddleRun) {
    start_running();
    ASSERT_EQ(phase(), 2);
    for (int i = 0; i < 220; ++i)
        step();
    ASSERT_EQ(phase(), 3) << failure();
    EXPECT_FALSE(enabled());
    ready_ = false;
    status_[0] = status_[1] = 0;
    for (int i = 0; i < 30; ++i)
        step();
    EXPECT_EQ(phase(), 3);
    EXPECT_FALSE(enabled());
    left_ = right_ = Switch::DOWN;
    step();
    expect_down_reset();
    left_ = right_ = Switch::MIDDLE;
    step();
    EXPECT_EQ(phase(), 1) << failure();
    EXPECT_TRUE(enabled());
}

TEST_F(PairControllerTest, StaleRemoteDownCannotResetLatchedFault) {
    step(true, 1);
    step(true, 5);
    ASSERT_EQ(phase(), -1);
    left_ = right_ = Switch::DOWN;
    remote_fresh_ = false;
    step();
    EXPECT_EQ(phase(), -1);
    EXPECT_FALSE(enabled());
}

class PairProbeControllerTest : public PairControllerTest {
protected:
    void start_probe() {
        step();
        ASSERT_EQ(phase(), 1) << failure();
        ready_ = true;
        status_[0] = status_[1] = 1;
        for (int i = 0; i < 1200 && phase() == 1; ++i)
            step();
        ASSERT_EQ(phase(), 2) << failure();
    }

private:
    std::string stage() const override { return "probe"; }
};

TEST_F(PairProbeControllerTest, EstimatedBrakingCannotStopProbeButActualBoundaryDoes) {
    start_probe();
    ASSERT_EQ(phase(), 2);
    velocity_[1] = 0.55; // Estimated braking distance exceeds remaining spring room.
    step();
    EXPECT_EQ(phase(), 2) << failure();
    EXPECT_TRUE(enabled());
    angle_[1] = 1.4; // Actual relative-axis bound still applies, even at speed.
    step();
    EXPECT_EQ(phase(), -1);
    EXPECT_EQ(failure(), 103);
    EXPECT_FALSE(enabled());
}

TEST_F(PairProbeControllerTest, ProbeTrackingSpeedAndParkedMotionAreDiagnosticDownStillWins) {
    start_probe();
    ASSERT_EQ(phase(), 2);
    angle_[0] += 0.25;
    angle_[1] += 0.25; // Large tracking error without changing the coupled geometry.
    velocity_[0] = velocity_[1] = 1.0; // Above both speed and velocity-error thresholds.
    velocity_[2] = 0.2; // Opposite drive remains disabled despite passive motion.
    for (int i = 0; i < 8; ++i)
        step();
    EXPECT_EQ(phase(), 2) << failure();
    EXPECT_EQ(failure(), 0);
    EXPECT_TRUE(enabled());
    left_ = right_ = Switch::DOWN;
    feedback_fresh_ = false;
    feedback_ns_.fill(0);
    step(false);
    expect_down_reset();
}

TEST_F(PairProbeControllerTest, ActualProbeProfileStartsOnMiddleAndDownCancelsPreflight) {
    step();
    ASSERT_EQ(phase(), 1) << failure();
    ASSERT_TRUE(enabled());
    ready_ = true;
    status_[0] = status_[1] = 1;
    step();
    ASSERT_EQ(phase(), 1) << failure();
    left_ = right_ = Switch::DOWN;
    feedback_fresh_ = false;
    feedback_ns_.fill(0);
    step(false, 20, 100);
    expect_down_reset();
}


class PairSweepControllerTest : public PairControllerTest {
    std::string stage() const override { return "probe"; }
    std::string pattern() const override { return "rotation_chirp"; }
};

TEST_F(PairSweepControllerTest, MaterializedSweepPreflightsAndDownDisablesBothDrives) {
    step();
    ASSERT_EQ(phase(), 1);
    status_[0] = status_[1] = 1;
    ready_ = true;
    for (int i = 0; i < 2800 && phase() == 1; ++i)
        step();
    ASSERT_EQ(phase(), 2) << failure();
    ASSERT_TRUE(enabled());
    left_ = right_ = Switch::DOWN;
    step();
    expect_down_reset();
}


class PairMultibandControllerTest : public PairControllerTest {
protected:
    void start_multiband() {
        step();
        ASSERT_EQ(phase(), 1);
        status_[0] = status_[1] = 1;
        ready_ = true;
        for (int i = 0; i < 7000 && phase() == 1; ++i)
            step();
        ASSERT_EQ(phase(), 2) << failure();
    }
    std::string stage() const override { return "probe"; }
    std::string pattern() const override { return "multiband_chirp"; }
    const char* profile_path() const override { return PAIR_MULTIBAND_TEST_PROFILE; }
};

TEST_F(PairMultibandControllerTest, ActualProfilePreflightsWithoutTimeoutAndDownCancels) {
    step();
    ASSERT_EQ(phase(), 1);
    status_[0] = status_[1] = 1;
    ready_ = true;
    for (int i = 0; i < 7000 && phase() == 1; ++i)
        step();
    ASSERT_EQ(phase(), 2) << failure();
    EXPECT_TRUE(enabled());
    left_ = right_ = Switch::DOWN;
    step();
    expect_down_reset();
}


TEST_F(PairMultibandControllerTest, RecordedThirteenMillisecondGapRetainsIntegralAndResumesNextTick) {
    start_multiband();
    angle_[0] -= .01;
    step();
    const double integral = output<Eigen::Vector4d>("identification/torque_integral_model")[0];
    ASSERT_GT(integral, 0);
    // Real Executor skips scheduled periods but its component update counter
    // still increments once. Replay the observed 13 ms scheduled-time gap.
    step(true, 1, 13);
    ASSERT_EQ(phase(), 2) << failure();
    EXPECT_TRUE(enabled());
    EXPECT_DOUBLE_EQ(output<Eigen::Vector4d>("identification/torque_integral_model")[0], integral);
    EXPECT_NEAR(output<double>("left_hip_joint/control_torque"), .6 + integral, 1e-10);
    step();
    ASSERT_EQ(phase(), 2) << failure();
    EXPECT_NEAR(output<Eigen::Vector4d>("identification/torque_integral_model")[0], integral + .5*.06*.001, 1e-12);
}

TEST_F(PairMultibandControllerTest, BudgetBoundaryIsSharedWithCascadeAndLongGapStillDisables) {
    start_multiband();
    step(true, 1, 20);
    ASSERT_EQ(phase(), 2) << failure();
    step(true, 1, 21);
    EXPECT_EQ(phase(), -1);
    EXPECT_EQ(failure(), 2);
    EXPECT_FALSE(enabled());
}

TEST_F(PairMultibandControllerTest, ShortTimingGapDoesNotBypassFeedbackLossOrDownPriority) {
    start_multiband();
    feedback_ns_[0] = 0;
    step(false, 1, 13);
    EXPECT_EQ(phase(), -1);
    EXPECT_EQ(failure(), 40);
    EXPECT_FALSE(enabled());
    left_ = right_ = Switch::DOWN;
    step(false, 8, -100);
    expect_down_reset();
}

TEST_F(PairMultibandControllerTest, ClockRollbackStillDisablesWithinJitterBudget) {
    start_multiband();
    step(true, 1, -1);
    EXPECT_EQ(phase(), -1);
    EXPECT_EQ(failure(), 2);
    EXPECT_FALSE(enabled());
}

TEST_F(PairMultibandControllerTest, DiagnosticDeltaCrossingContinuesUntilOperatorDown) {
    start_multiband();
    // Reproduce a crossing 0.0012 rad below the configured motor-axis proxy.
    // Keep independent root coordinates finite and within their bounds.
    angle_[1] = .44 + .005 - .0012;
    for (int i = 0; i < 30; ++i)
        step();
    EXPECT_EQ(phase(), 2) << failure();
    EXPECT_TRUE(enabled());
    left_ = right_ = Switch::DOWN;
    step();
    expect_down_reset();
}

TEST_F(PairMultibandControllerTest, DiagnosticDeltaDoesNotAdmitOutsideInitialPose) {
    angle_[1] = .44;
    step();
    EXPECT_EQ(phase(), -1);
    EXPECT_EQ(failure(), 103);
    EXPECT_FALSE(enabled());
}

TEST_F(PairMultibandControllerTest, DiagnosticDeltaDoesNotBypassFreshFeedback) {
    start_multiband();
    angle_[1] = .44;
    step();
    ASSERT_EQ(phase(), 2);
    feedback_ns_[1] = 0;
    step(false);
    EXPECT_EQ(phase(), -1);
    EXPECT_EQ(failure(), 41);
    EXPECT_FALSE(enabled());
}

class PairMultibandStrictDeltaTest : public PairMultibandControllerTest {
    std::string delta_policy_override() const override { return "stop"; }
};

TEST_F(PairMultibandStrictDeltaTest, StopPolicyStillRejectsMeasuredDeltaCrossing) {
    start_multiband();
    angle_[1] = .44;
    step();
    EXPECT_EQ(phase(), -1);
    EXPECT_EQ(failure(), 103);
    EXPECT_FALSE(enabled());
}

TEST(PairObservationBounds, IgnoringDeltaCannotMaskRootOrNonfiniteFault) {
    PairLimits limits;
    limits.root_min.fill(-2.);
    limits.root_max.fill(2.);
    limits.joint_margin = .05;
    limits.spring_min.fill(.44);
    limits.spring_max.fill(1.32);
    limits.spring_margin = .005;
    EXPECT_EQ(check_probe_pair(limits, 0, {2.1, 2.2}, {0., 0.}, false, false), PairFault::kRootLimit);
    EXPECT_EQ(check_probe_pair(limits, 0, {0., std::numeric_limits<double>::quiet_NaN()},
                               {0., 0.}, false, false), PairFault::kNonfinite);
    EXPECT_EQ(check_probe_pair(limits, 0, {0., .44}, {0., 0.}, false), PairFault::kSpringLimit);
}

class PairPdControllerTest : public PairControllerTest {
protected:
    std::vector<std::string> extra_parameters() const override {
        return {"control_law:=rl_pd", "control_frequency_hz:=1000.0",
                "reference_frequency_hz:=50.0", "pd_kp:=[60.0,60.0,60.0,60.0]",
                "pd_kd:=[2.0,2.0,2.0,2.0]", "ki_velocity:=[0.0,0.0,0.0,0.0]",
                "integral_limit:=[0.0,0.0,0.0,0.0]", "dm_motor_family:=DM-J8009",
                "dm_rated_torque_nm:=20.0", "dm_peak_torque_nm:=40.0"};
    }
};

TEST_F(PairPdControllerTest, PurePdRecomputesEveryTickWhileThePositionReferenceIsHeld) {
    start_running();
    ASSERT_EQ(phase(), 2);
    // Hold captures q=0. PD must react to each fresh feedback sample, even
    // though the reference is held; 1 kHz transmission alone is insufficient.
    angle_[0] = .01;
    velocity_[0] = .1;
    step();
    EXPECT_NEAR(output<double>("left_hip_joint/control_torque"), -.8, 1e-12);
    EXPECT_TRUE(output<Eigen::Vector4d>("identification/velocity_target_model").isZero());
    EXPECT_TRUE(output<Eigen::Vector4d>("identification/torque_integral_model").isZero());
    EXPECT_TRUE(output<Eigen::Vector4d>("identification/torque_gravity_ff_model").isZero());
    velocity_[0] = -.2;
    step();
    EXPECT_NEAR(output<double>("left_hip_joint/control_torque"), -.2, 1e-12);
    // Operator disable is never decimated with the PD calculation.
    left_ = right_ = Switch::DOWN;
    step(false);
    expect_down_reset();
}

TEST_F(PairPdControllerTest, LiveTorqueLimitBelowConfiguredAuthorityReleasesThePair) {
    start_running();
    max_torque_[0] = .5;
    angle_[0] = .02;
    for (int i = 0; i < 5; ++i)
        step();
    EXPECT_EQ(phase(), -1);
    EXPECT_EQ(failure(), 5);
    EXPECT_TRUE(std::isnan(output<double>("left_hip_joint/control_torque")));
}

TEST(PairPdMath, PositionAndDampingAreClippedTogetherWithoutIntegralOrFeedforward) {
    const auto result = pd_step(.1, 0., -20., 60., 2., 40.);
    EXPECT_DOUBLE_EQ(result.preclip, 46.);
    EXPECT_DOUBLE_EQ(result.torque, 40.);
    EXPECT_DOUBLE_EQ(result.integral_torque, 0.);
    EXPECT_DOUBLE_EQ(result.velocity_target, 0.);
    EXPECT_DOUBLE_EQ(pd_step(-.1, 0., 20., 60., 2., 40.).torque, -40.);
}

class PairPdProbeControllerTest : public PairPdControllerTest {
protected:
    std::string stage() const override { return "probe"; }
};

TEST_F(PairPdProbeControllerTest, MovingReferenceIsHeldTwentyTicksWhilePdUsesFreshFeedback) {
    step();
    status_[0] = status_[1] = 1;
    ready_ = true;
    for (int i = 0; i < 1000 && phase() == 1; ++i)
        step();
    ASSERT_EQ(phase(), 2) << failure();
    const auto start_tick = tick_;
    auto previous = output<Eigen::Vector4d>("identification/reference_model");
    int changed = 0;
    for (int i = 0; i < 4500; ++i) {
        step();
        ASSERT_EQ(phase(), 2) << failure();
        const auto current = output<Eigen::Vector4d>("identification/reference_model");
        if (!current.isApprox(previous, 1e-14)) {
            EXPECT_EQ((tick_ - start_tick) % 20, 0u);
            ++changed;
        }
        EXPECT_TRUE(output<Eigen::Vector4d>("identification/torque_integral_model").isZero());
        previous = current;
    }
    EXPECT_GT(changed, 5);
}

class PairPdFastReferenceControllerTest : public PairPdProbeControllerTest {
protected:
    std::vector<std::string> extra_parameters() const override {
        auto parameters = PairPdProbeControllerTest::extra_parameters();
        for (auto& parameter : parameters)
            if (parameter.starts_with("reference_frequency_hz:="))
                parameter = "reference_frequency_hz:=200.0";
        return parameters;
    }
};

TEST_F(PairPdFastReferenceControllerTest, ReferenceChangesEveryFiveTicksButPdEveryTick) {
    step();
    status_[0] = status_[1] = 1;
    ready_ = true;
    for (int i = 0; i < 1000 && phase() == 1; ++i)
        step();
    ASSERT_EQ(phase(), 2) << failure();
    const auto start_tick = tick_;
    auto previous = output<Eigen::Vector4d>("identification/reference_model");
    int changed = 0;
    for (int i = 0; i < 4500; ++i) {
        velocity_[0] = i % 2 ? .01 : -.01;
        step();
        ASSERT_EQ(phase(), 2) << failure();
        const auto current = output<Eigen::Vector4d>("identification/reference_model");
        if (!current.isApprox(previous, 1e-14)) {
            EXPECT_EQ((tick_ - start_tick) % 5, 0u);
            ++changed;
        }
        EXPECT_DOUBLE_EQ(output<Eigen::Vector4d>("identification/speed_error_model")[0], -velocity_[0]);
        previous = current;
    }
    EXPECT_GT(changed, 20);
}

} // namespace
} // namespace rmcs_core::controller::identification
