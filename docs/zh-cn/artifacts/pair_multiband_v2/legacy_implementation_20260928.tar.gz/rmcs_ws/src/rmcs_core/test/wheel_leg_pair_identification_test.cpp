#include <array>
#include <cmath>
#include <numbers>
#include <stdexcept>

#include <gtest/gtest.h>

#include "identification/wheel_leg_arm_dwell.hpp"
#include "identification/wheel_leg_pair_sweep_plan.hpp"
#include "identification/wheel_leg_pair_multiband_plan.hpp"
#include "identification/wheel_leg_pair_identification_planner.hpp"

namespace rmcs_core::controller::identification {
namespace {

KneeLut measured_knee() { return {{40.0, 60.0, 85.0, 105.0}, {0.46, 0.7, 1.0, 1.3}}; }

PairLimits limits() {
    PairLimits result;
    result.sign = {-1, 1, 1, -1};
    result.offset = {0.1, 0.2, -0.1, -0.2};
    result.root_min.fill(-2.0);
    result.root_max.fill(2.0);
    result.max_speed.fill(2.0);
    result.max_acceleration.fill(8.0);
    result.braking_acceleration.fill(6.0);
    result.max_torque.fill(4.0);
    result.inertia_bound.fill(0.02);
    result.load_torque_bound.fill(0.05);
    result.viscous_bound.fill(0.01);
    result.spring_min = {0.44, 0.44};
    result.spring_max = {1.32, 1.32};
    result.joint_margin = 0.04;
    result.spring_margin = 0.02;
    result.beta_margin = std::numbers::pi / 180.0;
    return result;
}

PairTrajectoryConfig path() {
    PairTrajectoryConfig config;
    config.pose_hip = {0.0, 0.25, 0.0, -0.15};
    config.pose_beta_degrees = {75, 75, 85, 80};
    config.frequencies_hz = {0.7, 1.2};
    config.hip_amplitudes = {0.004, 0.003};
    config.beta_amplitudes_degrees = {0.2, 0.15};
    config.max_hip_excitation = 0.02;
    config.max_beta_excitation_degrees = 1.0;
    config.move_s = 2.5;
    config.hold_s = 0.5;
    config.excite_s = 2.0;
    return config;
}

TEST(WheelLegPairIdentification, MeasuredLutIsShapePreservingAndInvertibleOnEitherSide) {
    const auto lut = measured_knee();
    double previous = 0;
    for (double degrees = 40; degrees <= 105; degrees += 0.25) {
        const double beta = degrees * (std::numbers::pi / 180.0);
        const auto value = lut.at(beta);
        EXPECT_GT(value.delta, previous);
        EXPECT_GT(value.slope, 0.0);
        EXPECT_NEAR(lut.beta_from_delta(value.delta), beta, 1e-11);
        previous = value.delta;
    }
    EXPECT_THROW((KneeLut{{40, 70, 105}, {0.5, 0.6, 0.59}}), std::invalid_argument);
    EXPECT_NO_THROW((KneeLut{{50, 70, 100}, {0.5, 0.6, 0.7}}));
    EXPECT_THROW((KneeLut{{39, 70, 100}, {0.5, 0.6, 0.7}}), std::invalid_argument);
    EXPECT_THROW((KneeLut{{40, 70, 105.1}, {0.5, 0.6, 0.7}}), std::invalid_argument);
    EXPECT_THROW((KneeLut{{}, {}}), std::invalid_argument);
    const KneeLut decreasing{{40, 75, 105}, {1.3, 1.0, 0.7}};
    EXPECT_NEAR(decreasing.beta_from_delta(decreasing.at(1.25).delta), 1.25, 1e-11);
    EXPECT_EQ(check_pair(limits(), lut, 1, {0.0, 1.8}, {0.0, 0.0}), PairFault::kSpringLimit);
    const double physical_edge = lut.at(104.5 * (std::numbers::pi / 180.0)).delta;
    EXPECT_EQ(check_pair(limits(), lut, 0, {0, physical_edge}, {0, 0}), PairFault::kKneeLimit);
}

TEST(WheelLegPairIdentification, CoupledTrajectoriesHavePhysicalReversalsAndBothDriveDerivatives) {
    const auto lut = measured_knee();
    const auto config = path();
    const auto initial = lut.at(78 * std::numbers::pi / 180.0);
    const PairPlanner planner(config, lut, limits().beta_margin, 0.10, initial.delta);
    EXPECT_NEAR(planner.at(0).position[0], 0.10, 1e-12);
    EXPECT_NEAR(planner.at(0).position[1], 0.10 + initial.delta, 1e-12);
    // Move 0 to 1 is fixed-beta common rotation; 1 back to 0 is its reversal.
    const double common_t = config.move_s + config.hold_s + config.move_s / 2;
    const auto common = planner.at(common_t);
    EXPECT_NEAR(
        common.position[1] - common.position[0], lut.at(75 * std::numbers::pi / 180.0).delta,
        1e-12);
    EXPECT_NEAR(common.velocity[0], common.velocity[1], 1e-12);
    const auto reversed =
        planner.at(common_t + config.move_s / 2 + config.hold_s + config.move_s / 2);
    EXPECT_LT(reversed.velocity[0], 0);
    // Flexion holds the hip fixed and moves the auxiliary drive along the measured LUT.
    const double flex_t = 3 * (config.move_s + config.hold_s) + config.move_s / 2;
    const auto flex = planner.at(flex_t);
    EXPECT_NEAR(flex.velocity[0], 0, 1e-12);
    EXPECT_GT(std::abs(flex.velocity[1]), 0.01);
    bool excited_both = false;
    for (double t = 0; t <= planner.duration(); t += 0.0025) {
        const auto sample = planner.at(t);
        EXPECT_EQ(check_reference(limits(), lut, 0, sample), PairFault::kNone) << "time " << t;
        if (sample.segment_id >= 10 && std::abs(sample.velocity[0]) > 0.001
            && std::abs(sample.velocity[1] - sample.velocity[0]) > 0.001)
            excited_both = true;
    }
    EXPECT_TRUE(excited_both);
}

TEST(WheelLegPairIdentification, BothSidesUseOnlyTheirOwnHipAndAuxKnee) {
    auto calibration = limits();
    const auto left = selected_torque_api(0, calibration, {1.0, -0.8});
    const auto right = selected_torque_api(1, calibration, {1.0, -0.8});
    EXPECT_EQ(left, (std::array<double, 6>{-1.0, -0.8, 0, 0, 0, 0}));
    EXPECT_EQ(right, (std::array<double, 6>{0, 0, 1.0, 0.8, 0, 0}));
    EXPECT_EQ(selected_torque_api(2, calibration, {1, 1}), (std::array<double, 6>{}));
    for (std::size_t side = 0; side < 2; ++side) {
        const auto model_q = measured_knee().at(80 * std::numbers::pi / 180.0).delta;
        EXPECT_EQ(
            check_pair(calibration, measured_knee(), side, {0, model_q}, {0, 0}), PairFault::kNone);
        EXPECT_EQ(
            check_pair(calibration, measured_knee(), side, {1.94, 1.94 + model_q}, {1.5, 1.5}),
            PairFault::kRootLimit);
    }
}

TEST(WheelLegPairIdentification, LegacyMotorZeroOffsetsLiftApiPhaseAroundCalibrationPose) {
    constexpr double period = 2.0 * std::numbers::pi;
    const auto angle = period * 2.0 - 0.15;
    EXPECT_NEAR(model_angle_from_api(angle, 1.0, -1.6, true), -1.75, 1e-12);
    EXPECT_NEAR(model_angle_from_api(-angle, 1.0, 1.6, true), 1.75, 1e-12);
    EXPECT_NEAR(model_angle_from_api(0.0, 1.0, -2.93, true), -2.93, 1e-12);
    EXPECT_NEAR(model_angle_from_api(angle, 1.0, -1.6, false), angle - 1.6, 1e-12);
    // Real old-driver feedback at this rig pose: wrapping API first would
    // incorrectly report a model joint approximately -4.56 rad here.
    EXPECT_NEAR(model_angle_from_api(3.32732, 1.0, -1.6, true), 1.72732, 1e-5);
    EXPECT_NEAR(model_angle_from_api(3.302145, 1.0, -2.93, true), .372145, 1e-5);
    EXPECT_NEAR(unwrap_model_phase(-3.13, 3.13), 2 * std::numbers::pi - 3.13, 1e-12);
    EXPECT_NEAR(unwrap_model_phase(3.13, -3.13), -2 * std::numbers::pi + 3.13, 1e-12);
    const double aligned_knee = align_auxiliary_to_pair_branch(-3.05, 3.10, -1.42, .16);
    EXPECT_NEAR(aligned_knee - 3.10, 2 * std::numbers::pi - 6.15, 1e-12);
    // The inner knee is a separate closed-chain coordinate, not this 1.33 rad difference.
    EXPECT_NEAR(
        model_angle_from_api(0.0, 1.0, -2.93, true) - model_angle_from_api(0.0, 1.0, -1.6, true),
        -1.33, 1e-12);
    EXPECT_NEAR(
        model_angle_from_api(0.0, 1.0, 2.93, true) - model_angle_from_api(0.0, 1.0, 1.6, true),
        1.33, 1e-12);
}

TEST(WheelLegPairIdentification, DownDwellSurvivesSequentialSwitchTransition) {
    using rmcs_msgs::Switch;
    WheelLegArmDwell arm;
    const auto t0 = WheelLegArmDwell::Clock::now();
    const auto step = [&](int ms, Switch left, Switch right, bool fresh = true) {
        return arm.update(t0 + std::chrono::milliseconds{ms}, fresh, left, right, .5);
    };
    EXPECT_FALSE(step(0, Switch::DOWN, Switch::DOWN));
    EXPECT_FALSE(step(500, Switch::DOWN, Switch::DOWN));
    EXPECT_FALSE(step(501, Switch::MIDDLE, Switch::DOWN));
    EXPECT_TRUE(step(650, Switch::MIDDLE, Switch::MIDDLE));
    EXPECT_FALSE(step(651, Switch::MIDDLE, Switch::MIDDLE));
    EXPECT_FALSE(step(1000, Switch::DOWN, Switch::DOWN));
    EXPECT_FALSE(step(1100, Switch::MIDDLE, Switch::DOWN));
    EXPECT_FALSE(step(1200, Switch::MIDDLE, Switch::MIDDLE));
    EXPECT_FALSE(step(2000, Switch::DOWN, Switch::DOWN));
    EXPECT_FALSE(step(2500, Switch::DOWN, Switch::DOWN, false));
    EXPECT_FALSE(step(2600, Switch::MIDDLE, Switch::MIDDLE));
}

TEST(WheelLegPairIdentification, MotorProbeReturnsAndBoundsBothCoordinatedDrives) {
    auto bounds = limits();
    bounds.root_min.fill(-3.14);
    bounds.root_max.fill(3.14);
    bounds.spring_min = {-1.42, -0.16};
    bounds.spring_max = {0.16, 1.42};
    bounds.spring_margin = 0.005;
    bounds.joint_margin = 0.05;
    bounds.max_speed.fill(0.3);
    bounds.max_acceleration.fill(0.8);
    bounds.braking_acceleration.fill(0.4);
    PairProbeConfig settings;
    settings.common_amplitude = .04;
    settings.knee_amplitude = .08;
    settings.sine_common_amplitude = .02;
    settings.sine_knee_amplitude = .015;
    settings.move_s = 2.5;
    settings.hold_s = .7;
    settings.excite_s = 8.;
    settings.frequencies_hz = {.35, .75};
    settings.validation_s = 6.;
    settings.validation_frequencies_hz = {.5, .9};
    settings.gravity_hold_s = 1.5;
    settings.step_amplitude = .025;
    settings.step_rise_s = .6;
    settings.triangle_amplitude = .02;
    settings.triangle_frequency_hz = .2;
    settings.triangle_s = 10.;
    const PairProbePlan probe(settings, {-1.6, -2.42});
    EXPECT_NEAR(probe.duration(), 87.2, 1e-12);
    EXPECT_EQ(check_probe_pair(bounds, 0, {-1.6, -2.93}, {0, 0}), PairFault::kNone);
    EXPECT_EQ(check_probe_pair(bounds, 0, {-1.6, -2.42}, {0, 0}), PairFault::kNone);
    EXPECT_EQ(check_probe_pair(bounds, 0, {1.72732, .372145}, {0, 0}), PairFault::kNone);
    EXPECT_EQ(probe_inward_direction(bounds, 0, .372145 - 1.72732), 1);
    EXPECT_EQ(probe_inward_direction(bounds, 1, 1.337), -1);
    EXPECT_EQ(probe_inward_direction(bounds, 0, -.82), 0);
    EXPECT_FALSE(probe_has_interior_room(1, -1.37, -1.362, .02));
    EXPECT_TRUE(probe_has_interior_room(1, -1.37, -1.345, .02));
    EXPECT_FALSE(probe_has_interior_room(-1, 1.37, 1.362, .02));
    EXPECT_TRUE(probe_has_interior_room(-1, 1.37, 1.345, .02));
    const auto common_move = probe.at(.7 + 1.25);
    EXPECT_NEAR(common_move.position[0] + 1.6, common_move.position[1] + 2.42, 1e-12);
    EXPECT_GT(common_move.position[0], -1.6);
    bool knee_move = false, two_tones = false, validation = false, step = false, triangle = false;
    for (double t = 0; t <= probe.duration(); t += .001) {
        const auto sample = probe.at(t);
        EXPECT_EQ(check_probe_reference(bounds, 0, sample), PairFault::kNone) << "time " << t;
        knee_move |= sample.waveform == 1 && std::abs(sample.position[0] + 1.6) < 1e-12
                  && sample.position[1] > -2.419;
        if (sample.waveform == 2 && std::abs(sample.velocity[0]) > 1e-5
            && std::abs(sample.velocity[1] - sample.velocity[0]) > 1e-5)
            two_tones = true;
        step |= sample.waveform == 3 && std::abs(sample.velocity[0]) > 1e-5;
        triangle |= sample.waveform == 4 && std::abs(sample.velocity[0]) > 1e-5;
        validation |= sample.validation && sample.waveform == 5;
    }
    EXPECT_TRUE(two_tones);
    EXPECT_TRUE(knee_move);
    EXPECT_TRUE(validation);
    EXPECT_TRUE(step);
    EXPECT_TRUE(triangle);
    EXPECT_NEAR(probe.at(probe.duration()).position[0], -1.6, 1e-12);
    EXPECT_NEAR(probe.at(probe.duration()).position[1], -2.42, 1e-12);

    const std::array at_old_stop{1.72732, .372145};
    const double initial_delta = at_old_stop[1] - at_old_stop[0];
    const int inward = probe_inward_direction(bounds, 0, initial_delta);
    const PairProbePlan near_stop(settings, at_old_stop, inward);
    EXPECT_NEAR(near_stop.duration(), probe.duration() + settings.move_s + settings.hold_s, 1e-12);
    const auto interior = near_stop.at(settings.hold_s + settings.move_s);
    EXPECT_NEAR(interior.position[0], at_old_stop[0], 1e-12);
    EXPECT_NEAR(interior.position[1], at_old_stop[1] + settings.knee_amplitude, 1e-12);
    for (double t = 0; t <= near_stop.duration(); t += .001) {
        const auto sample = near_stop.at(t);
        EXPECT_EQ(check_probe_reference(bounds, 0, sample), PairFault::kNone) << "time " << t;
        const double delta = sample.position[1] - sample.position[0];
        EXPECT_GE(delta, initial_delta - 1e-12);
    }
    EXPECT_NEAR(near_stop.at(near_stop.duration()).position[1], interior.position[1], 1e-12);
}

TEST(
    WheelLegPairIdentification,
    CascadeReportsTrajectoryDerivativeSeparatelyFromLimitedOuterTarget) {
    double integral = 0;
    const auto step =
        cascade_step(1.0, 0.15, 0.9, 0.03, 3.0, 2.0, 0.0, 0.4, 3.0, 0.0, 0.005, integral);
    EXPECT_NEAR(step.velocity_target, 0.4, 1e-12);
    EXPECT_NE(step.velocity_target, 0.15);
    EXPECT_NEAR(step.position_error, 0.1, 1e-12);
    EXPECT_NEAR(step.speed_error, 0.37, 1e-12);
    EXPECT_NEAR(step.preclip, 0.74, 1e-12);
    EXPECT_EQ(step.integral_torque, 0.0);
    EXPECT_EQ(integral, 0.0);
    const auto pd = cascade_step(1, 0, 0.9, 0.03, 3, 2, 0, 10, 10, 0, 0.005, integral);
    EXPECT_NEAR(pd.torque, 2.0 * (3.0 * (1.0 - 0.9) - 0.03), 1e-12);
    for (int i = 0; i < 100; ++i)
        cascade_step(2, 0, 0, 0, 3, 1, 2, 1, 0.2, 0.5, 0.005, integral);
    EXPECT_LE(std::abs(integral), 0.5);
    EXPECT_EQ(integral, 0.0); // saturated effort never winds up
}

TEST(WheelLegPairIdentification, RejectsHighSpeedBrakeFaultAndBadPreflight) {
    const auto lut = measured_knee();
    const auto config = limits();
    const double delta = lut.at(80 * std::numbers::pi / 180.0).delta;
    EXPECT_EQ(
        check_pair(config, lut, 0, {0.88, 0.88 + delta}, {1.9, 1.9}), PairFault::kStoppingDistance);
    const double near_edge_delta = lut.at(103.7 * std::numbers::pi / 180.0).delta;
    EXPECT_EQ(
        check_pair(config, lut, 1, {0, near_edge_delta}, {0, 0.3}), PairFault::kStoppingDistance);
    EXPECT_FALSE(motor_states_safe(0, {1, 1, 0, 0}, {0, 9, 0, 0}, true));
    EXPECT_TRUE(motor_states_safe(0, {8, 0, 0, 0}, {8, 0, 0, 0}, false, true));
    EXPECT_FALSE(motor_states_safe(0, {8, 0, 0, 0}, {8, 0, 0, 0}, true, true));
    EXPECT_FALSE(motor_states_safe(0, {0, 0, 8, 0}, {0, 0, 8, 0}, false, true));
    EXPECT_FALSE(motor_states_safe(0, {1, 8, 0, 0}, {0, 8, 0, 0}, false, true));
    EXPECT_TRUE(motor_states_safe(0, {0, 0, 0, 0}, {0, 0, 0, 0}, false));
    EXPECT_FALSE(motor_states_safe(0, {0, 0, 0, 0}, {0, 0, 0, 0}, true));
    EXPECT_FALSE(motor_states_safe(1, {1, 0, 1, 1}, {0, 0, 0, 0}, true));
    EXPECT_TRUE(motor_states_safe(1, {0, 0, 1, 1}, {0, 0, 0, 0}, true));
    auto bad = path();
    bad.pose_hip[1] = 3.0;
    const PairPlanner planner(bad, lut, config.beta_margin, 0.0, delta);
    bool rejected = false;
    for (double t = 0; t <= planner.duration(); t += 0.005)
        if (check_reference(config, lut, 0, planner.at(t)) != PairFault::kNone) {
            rejected = true;
            break;
        }
    EXPECT_TRUE(rejected);
    auto insufficient_torque = config;
    insufficient_torque.load_torque_bound[0] = 5.0;
    EXPECT_EQ(check_reference(insufficient_torque, lut, 0, planner.at(0)), PairFault::kTorque);
    auto too_much_energy = path();
    too_much_energy.hip_amplitudes = {0.2, 0.3};
    EXPECT_THROW(
        (PairPlanner{too_much_energy, lut, config.beta_margin, 0, delta}), std::invalid_argument);
}

TEST(WheelLegPairIdentification, ProbeGeometryDoesNotUseUnidentifiedBrakingOrSpeedEstimates) {
    auto config = limits();
    config.braking_acceleration.fill(0.4);
    EXPECT_EQ(check_probe_pair(config, 0, {0, 1}, {0, 1}), PairFault::kStoppingDistance);
    EXPECT_EQ(check_probe_pair(config, 0, {0, 1}, {0, 1}, false), PairFault::kNone);
    EXPECT_EQ(check_probe_pair(config, 0, {0, 1}, {3, 3}), PairFault::kSpeed);
    EXPECT_EQ(check_probe_pair(config, 0, {0, 1}, {3, 3}, false), PairFault::kNone);
    // A simultaneous large speed must not mask a real geometric violation.
    EXPECT_EQ(check_probe_pair(config, 0, {1.97, 2.97}, {3, 3}, false), PairFault::kRootLimit);
    EXPECT_EQ(check_probe_pair(config, 0, {0, 1.31}, {0, 3}, false), PairFault::kSpringLimit);
    EXPECT_EQ(
        check_probe_pair(config, 0, {0, 1}, {NAN, 0}, false), PairFault::kNonfinite);
}

TEST(WheelLegPairIdentification, SubsetAround105NeverExtrapolatesOrTreatsMotorZeroAsModelZero) {
    // Synthetic test measurements only: an L1 internal zero at 105 deg supplies no model offset.
    const KneeLut left{{95, 100, 103, 105}, {0.90, 0.95, 0.98, 1.00}};
    const KneeLut right{{94, 100, 104, 105}, {0.86, 0.94, 0.99, 1.00}};
    const auto calibration = limits();
    EXPECT_GT(left.beta_min(), KneeLut::kBetaMin);
    EXPECT_NEAR(left.beta_max(), KneeLut::kBetaMax, 1e-12);
    EXPECT_THROW((void)left.at(108 * std::numbers::pi / 180.0), std::out_of_range);
    EXPECT_THROW((void)right.beta_from_delta(1.02), std::out_of_range);

    for (std::size_t lut_index = 0; lut_index < 2; ++lut_index) {
        const auto& lut = lut_index == 0 ? left : right;
        for (std::size_t side = 0; side < 2; ++side) {
            const double delta_105 = lut.at(105 * std::numbers::pi / 180.0).delta;
            // Internal motor zero at 105 deg is the real stop, not an armable
            // trajectory start, even when the encoder velocity is zero.
            EXPECT_EQ(
                check_pair(calibration, lut, side, {0, delta_105}, {0, 0}), PairFault::kKneeLimit);
            EXPECT_EQ(
                check_pair(calibration, lut, side, {0, delta_105}, {0, 0.3}),
                PairFault::kKneeLimit);
            const double edge_delta = lut.at(lut.beta_max()).delta;
            EXPECT_EQ(
                check_pair(calibration, lut, side, {0, edge_delta}, {0, 0}), PairFault::kKneeLimit);
            EXPECT_EQ(
                check_pair(calibration, lut, side, {0, edge_delta + 0.01}, {0, 0}),
                PairFault::kKneeLimit);
        }
    }
    auto subset_path = path();
    subset_path.pose_beta_degrees = {98, 98, 102, 100};
    const double initial = left.at(100 * std::numbers::pi / 180.0).delta;
    const PairPlanner safe(subset_path, left, calibration.beta_margin, 0.12, initial);
    EXPECT_NEAR(safe.at(0).position[0], 0.12, 1e-12);
    EXPECT_EQ(check_reference(calibration, left, 0, safe.at(0)), PairFault::kNone);
    EXPECT_EQ(
        check_reference(
            calibration, left, 0,
            PairSample{
                {0, left.at(105 * std::numbers::pi / 180.0).delta},
                {0, 0},
                {0, 0},
                105 * std::numbers::pi / 180.0,
                -1}),
        PairFault::kKneeLimit);
    subset_path.pose_beta_degrees[2] = 105;
    EXPECT_THROW(
        (PairPlanner{subset_path, left, calibration.beta_margin, 0.12, initial}),
        std::invalid_argument);
    subset_path.pose_beta_degrees[2] = 103;
    EXPECT_THROW(
        (PairPlanner{
            subset_path, right, calibration.beta_margin, 0.12,
            right.at(105 * std::numbers::pi / 180.0).delta}),
        std::invalid_argument);
    const KneeLut too_narrow{{103, 104, 105}, {0.98, 0.99, 1.0}};
    EXPECT_THROW(
        (PairPlanner{
            subset_path, too_narrow, calibration.beta_margin, 0.12,
            too_narrow.at(104 * std::numbers::pi / 180.0).delta}),
        std::invalid_argument);
}

TEST(WheelLegPairIdentification, HoldCapturesBothModelMotorsWithoutTrajectoryOrMotionReference) {
    auto calibration = limits();
    calibration.inertia_bound.fill(0);
    calibration.load_torque_bound.fill(0);
    calibration.viscous_bound.fill(0);
    EXPECT_NO_THROW(validate_limits(calibration, false));
    EXPECT_THROW(validate_limits(calibration, true), std::invalid_argument);
    EXPECT_EQ(parse_experiment_stage("hold"), ExperimentStage::kHold);
    EXPECT_EQ(parse_experiment_stage("trajectory"), ExperimentStage::kTrajectory);
    EXPECT_THROW((void)parse_experiment_stage("sine"), std::invalid_argument);

    const std::array<KneeLut, 2> luts{measured_knee(), measured_knee()};
    const double delta = luts[0].at(80 * std::numbers::pi / 180.0).delta;
    const std::array<double, 4> pose{0.13, 0.13 + delta, -0.21, -0.21 + delta};
    const std::array<double, 4> speed{0, 0, 0, 0};
    for (std::size_t side = 0; side < 2; ++side) {
        const HoldPlan hold(calibration, luts, side, pose, speed, 0.5);
        EXPECT_EQ(hold.reference(), pose);
        EXPECT_FALSE(hold.finished(0.499));
        const auto sample = hold.at(0.499);
        EXPECT_EQ(sample.segment_id, 0);
        EXPECT_EQ(sample.position[0], pose[2 * side]);
        EXPECT_EQ(sample.position[1], pose[2 * side + 1]);
        EXPECT_EQ(sample.velocity, (std::array<double, 2>{0, 0}));
        EXPECT_EQ(sample.acceleration, (std::array<double, 2>{0, 0}));
        double integral = 0;
        const auto request = cascade_step(
            sample.position[0], sample.velocity[0], sample.position[0], 0, 3, 2, 0,
            calibration.max_speed[2 * side], 0.12, 0, 0.005, integral);
        EXPECT_EQ(request.position_error, 0);
        EXPECT_EQ(request.velocity_target, 0);
        EXPECT_EQ(request.torque, 0);
        const auto damping = cascade_step(
            sample.position[0], 0, sample.position[0], 0.2, 3, 2, 0,
            calibration.max_speed[2 * side], 0.12, 0, 0.005, integral);
        EXPECT_NEAR(damping.preclip, -0.4, 1e-12);
        EXPECT_NEAR(damping.torque, -0.12, 1e-12);
        EXPECT_TRUE(hold.finished(0.5));
        EXPECT_THROW((void)hold.at(0.5), std::out_of_range);
        EXPECT_EQ(selected_torque_api(side, calibration, {0, 0}), (std::array<double, 6>{}));
    }
    EXPECT_THROW((HoldPlan{calibration, luts, 0, pose, speed, 0}), std::invalid_argument);
    EXPECT_THROW((HoldPlan{calibration, luts, 0, pose, speed, 5.01}), std::invalid_argument);
}

TEST(WheelLegPairIdentification, HoldRejects105StopUnsafeOppositeSideAndRequiresDoubleDownDwell) {
    using Clock = std::chrono::steady_clock;
    const auto t0 = Clock::time_point{std::chrono::seconds{1}};
    EXPECT_FALSE(double_down_dwell_complete(t0, {}, 0.2));
    EXPECT_FALSE(double_down_dwell_complete(t0 + std::chrono::milliseconds{199}, t0, 0.2));
    EXPECT_TRUE(double_down_dwell_complete(t0 + std::chrono::milliseconds{200}, t0, 0.2));
    EXPECT_FALSE(double_down_dwell_complete(t0, t0 + std::chrono::milliseconds{1}, 0.2));

    const KneeLut near_stop{{95, 100, 103, 105}, {0.90, 0.95, 0.98, 1.00}};
    const std::array<KneeLut, 2> luts{near_stop, near_stop};
    const double safe_delta = near_stop.at(100 * std::numbers::pi / 180.0).delta;
    const double at_stop = near_stop.at(KneeLut::kBetaMax).delta;
    const std::array<double, 4> stopped{0, at_stop, 0, safe_delta};
    const std::array<double, 4> still{};
    for (std::size_t side = 0; side < 2; ++side) {
        // A stop on even the unpowered side blocks the run.
        EXPECT_THROW((HoldPlan{limits(), luts, side, stopped, still, 0.5}), std::invalid_argument);
        EXPECT_EQ(
            check_pair(limits(), near_stop, side, {0, at_stop}, {0, 0}), PairFault::kKneeLimit);
    }
    const std::array<double, 4> near_edge{
        0, near_stop.at(103.5 * std::numbers::pi / 180.0).delta, 0, safe_delta};
    const std::array<double, 4> moving{0, 0.3, 0, 0};
    EXPECT_THROW((HoldPlan{limits(), luts, 0, near_edge, moving, 0.5}), std::invalid_argument);
}


PairSweepConfig sweep_config() {
    PairSweepConfig c;
    c.common_amplitude = std::numbers::pi / 4;
    c.relative_amplitude = .2;
    c.common_step = std::numbers::pi / 12;
    c.relative_step = .15;
    c.step_rise_s = .8;
    c.move_s = 3;
    c.quarter_turn_s = 4;
    c.dwell_s = 2;
    c.chirp_s = 40;
    c.validation_s = 30;
    c.ramp_s = 3;
    c.relative_margin = .08;
    c.common_hz = {.05, .5};
    c.relative_hz = {.1, 1};
    return c;
}

TEST(WheelLegPairIdentification, FullTurnSweepFitsBothBranchesAndPreservesCommonGeometry) {
    auto lim = limits();
    lim.root_min.fill(-100);
    lim.root_max.fill(100);
    lim.max_speed.fill(4);
    lim.max_acceleration.fill(20);
    lim.braking_acceleration.fill(.4); // Unidentified braking cannot veto a reference.
    lim.spring_min = {-1.42, -.16};
    lim.spring_max = {.16, 1.42};
    lim.spring_margin = .005;
    for (std::size_t side : {0, 1}) {
        const double delta = side == 0 ? -1.35289 : 1.33;
        const PairSweepPlan plan(sweep_config(), {1, 1 + delta},
                                 lim.spring_min[side] + .005, lim.spring_max[side] - .005);
        double max_common = 0;
        bool common = false, relative = false, validation = false, step = false;
        for (double t = 0; t <= plan.duration(); t += .001) {
            const auto s = plan.at(t);
            ASSERT_EQ(check_probe_reference(lim, side, s), PairFault::kNone) << "side=" << side << " t=" << t;
            max_common = std::max(max_common, s.position[0] - 1);
            if (s.waveform == 7) {
                ASSERT_NEAR(s.velocity[0], s.velocity[1], 1e-12);
                ASSERT_NEAR(s.acceleration[0], s.acceleration[1], 1e-12);
            }
            if (s.waveform == 6 && !s.validation) {
                common |= std::abs(s.velocity[0]) > .5;
                relative |= std::abs(s.velocity[1] - s.velocity[0]) > .5;
            }
            validation |= s.validation && s.waveform == 6;
            step |= s.waveform == 3;
        }
        EXPECT_NEAR(max_common, 2 * std::numbers::pi, 1e-10);
        EXPECT_TRUE(common && relative && validation && step);
        EXPECT_NEAR(plan.at(plan.duration()).position[0], 1, 1e-12);
        EXPECT_EQ(plan.at(plan.duration()).velocity, (std::array<double, 2>{0, 0}));
        EXPECT_THROW((void)plan.at(plan.duration() + .01), std::out_of_range);
    }
}

TEST(WheelLegPairIdentification, SweepDerivativesRemainContinuousIncludingPhaseSeamsAndChirpEdges) {
    const PairSweepPlan plan(sweep_config(), {2.9, 1.55}, -1.415, .155);
    constexpr double h = 1e-5;
    auto previous = plan.at(0);
    std::array<double, 2> unwrapped = previous.position;
    for (double t = .001; t < plan.duration() - h; t += .001) {
        const auto s = plan.at(t);
        for (std::size_t j = 0; j < 2; ++j) {
            unwrapped[j] = unwrap_model_phase(std::remainder(s.position[j], 2 * std::numbers::pi), unwrapped[j]);
            ASSERT_NEAR(unwrapped[j], s.position[j], 1e-11) << t;
            ASSERT_LT(std::abs(s.position[j] - previous.position[j]), .004);
            ASSERT_LT(std::abs(s.velocity[j] - previous.velocity[j]), .020);
        }
        if (static_cast<int>(t * 1000) % 37 == 0) {
            const auto a = plan.at(t - h), b = plan.at(t + h);
            for (std::size_t j = 0; j < 2; ++j) {
                ASSERT_NEAR((b.position[j] - a.position[j]) / (2 * h), s.velocity[j], 2e-6) << t;
                ASSERT_NEAR((b.velocity[j] - a.velocity[j]) / (2 * h), s.acceleration[j], 2e-5) << t;
            }
        }
        previous = s;
    }
}

TEST(WheelLegPairIdentification, ChirpHasIncreasingFrequencyAndFullPlateauAmplitude) {
    const auto c = sweep_config();
    const PairSweepPlan plan(c, {0, -.8}, -1.415, .155);
    std::vector<double> crossings;
    double previous = 0, peak = 0;
    for (double t = 0; t < plan.duration(); t += .001) {
        const auto s = plan.at(t);
        if (s.waveform != 6 || s.validation || std::abs(s.position[0]) < 1e-12)
            continue;
        if (previous < 0 && s.position[0] >= 0)
            crossings.push_back(t);
        previous = s.position[0];
        peak = std::max(peak, std::abs(s.position[0]));
    }
    ASSERT_GE(crossings.size(), 5u);
    EXPECT_GT(crossings[1] - crossings[0],
              1.5 * (crossings.back() - crossings[crossings.size() - 2]));
    EXPECT_GT(peak, .99 * c.common_amplitude);
    auto invalid = c;
    invalid.ramp_s = 20;
    EXPECT_THROW((PairSweepPlan(invalid, {0, -.8}, -1.415, .155)), std::invalid_argument);
    EXPECT_THROW((PairSweepPlan(c, {0, .01}, 0, .8)), std::invalid_argument);
}


PairMultibandConfig multiband_config() {
    PairMultibandConfig c;
    c.common_hz = {.08, .5, 1.5, 4};
    c.relative_hz = {.1, .65, 1.8, 4};
    c.common_amplitude = {std::numbers::pi / 4, .20, .025};
    c.relative_amplitude = {.06, .035, .014};
    c.band_s = {24, 16, 12};
    c.shape_offset = .04;
    c.eighth_turn_s = 1.5;
    c.dwell_s = 1.5;
    c.ramp_s = 2;
    c.common_step = std::numbers::pi / 12;
    c.relative_step = .04;
    c.step_rise_s = .30;
    c.validation_s = 30;
    return c;
}

TEST(WheelLegPairIdentification, MultibandPreservesMeasuredAnchorAndMirrorsBranchClearance) {
    for (double sign : {-1., 1.}) {
        const std::array initial{sign * 1.031609, sign * -.3510346};
        const double low = sign > 0 ? -1.415 : -.155;
        const double high = sign > 0 ? .155 : 1.415;
        const PairMultibandPlan p(multiband_config(), initial, low, high);
        EXPECT_NEAR(p.duration(), 687.3, 1e-9);
        for (std::size_t i : {0, 1}) {
            EXPECT_NEAR(p.at(0).position[i], initial[i], 1e-12);
            EXPECT_NEAR(p.at(p.duration()).position[i], initial[i], 1e-12);
        }
        const double initial_delta = initial[1] - initial[0];
        EXPECT_NEAR(p.relative_amplitude(.04, initial_delta), .02588512, 1e-8);
        for (const auto& s : p.segments()) {
            if (s.kind == PairMultibandPlan::Kind::kCommon
                || s.kind == PairMultibandPlan::Kind::kRelative
                || s.kind == PairMultibandPlan::Kind::kMixed
                || s.kind == PairMultibandPlan::Kind::kGrid) {
                EXPECT_LE(std::abs(s.from[1] - initial_delta), .0400000001);
            }
            if (s.name == "shape0/pose0/differential_low") {
                double excursion = 0;
                for (double t = s.start_s; t < s.end_s; t += .01) {
                    const auto a = p.at(t);
                    EXPECT_NEAR(a.velocity[0] + a.velocity[1], 0, 1e-12);
                    EXPECT_NEAR(a.position[0] + a.position[1], initial[0] + initial[1], 1e-12);
                    excursion = std::max(excursion, std::abs(a.position[1] - a.position[0] - initial_delta));
                }
                EXPECT_GT(excursion, .025);
                EXPECT_LT(excursion, .026);
            }
        }
    }
}

TEST(WheelLegPairIdentification, MultibandEntireReferenceFitsBothSidesIncludingHighBandAndSteps) {
    auto lim = limits();
    lim.root_min.fill(-100); lim.root_max.fill(100);
    lim.max_speed.fill(4); lim.max_acceleration.fill(20);
    lim.spring_min = {-1.42, -.16}; lim.spring_max = {.16, 1.42}; lim.spring_margin = .005;
    for (std::size_t side : {0, 1}) {
        const double delta = side == 0 ? -1.38264 : 1.38264;
        const PairMultibandPlan p(multiband_config(), {1., 1. + delta},
                                 lim.spring_min[side] + .005, lim.spring_max[side] - .005);
        double high_energy = 0, validation_energy = 0;
        for (double t = 0; t < p.duration(); t += .001) {
            const auto s = p.at(t);
            ASSERT_EQ(check_probe_reference(lim, side, s), PairFault::kNone) << "t=" << t << " side=" << side;
            const auto& block = p.segments()[s.segment_id];
            if (block.kind == PairMultibandPlan::Kind::kMixed && block.band == 2)
                high_energy += std::abs(s.velocity[1] - s.velocity[0]) * .001;
            if (s.validation) {
                ASSERT_TRUE(s.waveform == 8 || s.waveform == 0);
                validation_energy += std::abs(s.velocity[0]) * .001;
            }
        }
        EXPECT_GT(high_energy, 2);
        EXPECT_GT(validation_energy, 1);
    }
}

TEST(WheelLegPairIdentification, MultibandAnalyticDerivativesAndAllJoinsAreContinuous) {
    const PairMultibandPlan p(multiband_config(), {2.9, 1.51736}, -1.415, .155);
    constexpr double h = 1e-5;
    for (const auto& block : p.segments()) {
        for (double t = block.start_s + .037; t < block.end_s - h; t += .137) {
            const auto a = p.at(t - h), b = p.at(t), c = p.at(t + h);
            for (std::size_t j : {0, 1}) {
                ASSERT_NEAR((c.position[j] - a.position[j]) / (2 * h), b.velocity[j], 1e-6) << block.name;
                ASSERT_NEAR((c.velocity[j] - a.velocity[j]) / (2 * h), b.acceleration[j], 1e-5) << block.name;
            }
        }
        for (double t : {block.start_s, block.start_s + 2, block.end_s - 2, block.end_s}) {
            if (t <= h || t >= p.duration() - h || t < block.start_s || t > block.end_s)
                continue;
            const auto a = p.at(t - h), b = p.at(t + h);
            for (std::size_t j : {0, 1}) {
                ASSERT_LT(std::abs(b.position[j] - a.position[j]), .0001) << block.name;
                ASSERT_LT(std::abs(b.velocity[j] - a.velocity[j]), .0005) << block.name;
                ASSERT_LT(std::abs(b.acceleration[j] - a.acceleration[j]), .02) << block.name;
            }
        }
    }
}

TEST(WheelLegPairIdentification, MultibandHasSixPoseExperimentsAndDisjointValidation) {
    const PairMultibandPlan p(multiband_config(), {1, -.38}, -1.415, .155);
    int common = 0, differential = 0, mixed = 0, validation = 0, grid = 0;
    for (const auto& s : p.segments()) {
        using K = PairMultibandPlan::Kind;
        common += s.kind == K::kCommon; differential += s.kind == K::kRelative;
        mixed += s.kind == K::kMixed; grid += s.kind == K::kGrid;
        if (s.kind != K::kMultisine)
            continue;
        ++validation;
        EXPECT_TRUE(s.validation);
        // Neither channel's reference is a scalar copy of the other.
        double cc = 0, dd = 0, cd = 0;
        for (double t = s.start_s + 2; t < s.end_s - 2; t += .001) {
            const auto a = p.at(t);
            const double c = (a.velocity[0] + a.velocity[1]) / 2;
            const double d = a.velocity[1] - a.velocity[0];
            cc += c*c; dd += d*d; cd += c*d;
        }
        EXPECT_GT(cc*dd - cd*cd, .95*cc*dd);
    }
    EXPECT_EQ(common, 6); EXPECT_EQ(differential, 6); EXPECT_EQ(mixed, 12);
    EXPECT_EQ(validation, 2); EXPECT_EQ(grid, 32);
}

TEST(WheelLegPairIdentification, MultibandRejectsInvalidConfigurationRatherThanFallingBack) {
    auto c = multiband_config();
    c.relative_hz[2] = c.relative_hz[1];
    EXPECT_THROW((PairMultibandPlan(c, {1, -.38}, -1.415, .155)), std::invalid_argument);
    c = multiband_config(); c.ramp_s = 6;
    EXPECT_THROW((PairMultibandPlan(c, {1, -.38}, -1.415, .155)), std::invalid_argument);
    c = multiband_config();
    EXPECT_THROW((PairMultibandPlan(c, {1, -.42}, -1.415, .155)), std::invalid_argument);
    c = multiband_config(); c.load_offset = .201;
    EXPECT_THROW((PairMultibandPlan(c, {1, -.38}, -1.415, .155)), std::invalid_argument);
}

TEST(WheelLegPairIdentification, LoadedMultibandBuildsPairedLoadAndReturnsToMeasuredPose) {
    auto c = multiband_config();
    c.load_offset = .2; c.validation_relative_scale = 3;
    c.common_hz = {.08, .75, 2, 6}; c.relative_hz = {.1, .9, 2.5, 6};
    c.common_amplitude = {std::numbers::pi / 3, .32, .04};
    c.relative_amplitude = {.12, .08, .025};
    c.eighth_turn_s = .8; c.common_step = .35; c.relative_step = .12; c.step_rise_s = .22;
    auto lim = limits();
    lim.root_min.fill(-100); lim.root_max.fill(100);
    lim.max_speed.fill(6); lim.max_acceleration.fill(80);
    lim.spring_min = {-1.42, -.16}; lim.spring_max = {.16, 1.42}; lim.spring_margin = .005;
    for (std::size_t side : {0, 1}) {
        const double direction = side == 0 ? 1 : -1;
        const std::array initial{1., 1. - direction * 1.38264};
        const PairMultibandPlan p(c, initial, lim.spring_min[side] + .005,
                                 lim.spring_max[side] - .005);
        EXPECT_NEAR(p.duration(), 671.42, 1e-9);
        EXPECT_EQ(p.segments().size(), 161u);
        int load_holds = 0;
        double relative_excursion = 0, validation_excursion = 0;
        for (const auto& block : p.segments()) {
            if (block.name.starts_with("spring_load/") && block.kind == PairMultibandPlan::Kind::kHold) {
                ++load_holds;
                const auto s = p.at(block.start_s + .1);
                EXPECT_NEAR(s.position[0] + s.position[1], initial[0] + initial[1], 1e-12);
                EXPECT_NEAR(s.position[1] - s.position[0], initial[1] - initial[0]
                            + direction * .05 * load_holds, 1e-12);
            }
            const double h = 1e-6;
            if (block.start_s > h) {
                const auto before = p.at(block.start_s - h), after = p.at(block.start_s + h);
                for (std::size_t j : {0, 1}) {
                    EXPECT_NEAR(before.position[j], after.position[j], 1e-5);
                    EXPECT_NEAR(before.velocity[j], after.velocity[j], 1e-5);
                    EXPECT_NEAR(before.acceleration[j], after.acceleration[j], .005);
                }
            }
        }
        EXPECT_EQ(load_holds, 4);
        for (double t = 0; t < p.duration(); t += .001) {
            const auto s = p.at(t);
            ASSERT_EQ(check_probe_reference(lim, side, s), PairFault::kNone) << t;
            const auto& block = p.segments()[s.segment_id];
            const double excursion = std::abs(s.position[1] - s.position[0] - block.from[1]);
            if (block.kind == PairMultibandPlan::Kind::kRelative)
                relative_excursion = std::max(relative_excursion, excursion);
            if (s.validation)
                validation_excursion = std::max(validation_excursion, excursion);
        }
        EXPECT_GT(relative_excursion, .119);
        EXPECT_GT(validation_excursion, .07);
        for (std::size_t j : {0, 1}) {
            EXPECT_NEAR(p.at(0).position[j], initial[j], 1e-12);
            EXPECT_NEAR(p.at(p.duration()).position[j], initial[j], 1e-12);
        }
    }
}

} // namespace
} // namespace rmcs_core::controller::identification
